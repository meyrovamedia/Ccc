import React, { useState, useEffect, useMemo } from 'react';
import { PRODUCTS, Product } from './data/products';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategoryNav } from './components/CategoryNav';
import { FilterSidebar } from './components/FilterSidebar';
import { ProductToolbar } from './components/ProductToolbar';
import { ProductGrid } from './components/ProductGrid';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer, CartItem } from './components/CartDrawer';
import { WishlistModal } from './components/WishlistModal';
import { CheckoutModal } from './components/CheckoutModal';
import { BenefitsStrip } from './components/BenefitsStrip';
import { Footer } from './components/Footer';
import { AdminPanel } from './components/AdminPanel';
import { CustomerAccountModal } from './components/CustomerAccountModal';
import { CustomerSupportModal } from './components/CustomerSupportModal';
import { LegalPolicyModal } from './components/LegalPolicyModal';

export default function App() {
  const [productsList, setProductsList] = useState<Product[]>(PRODUCTS);
  const [activeNav, setActiveNav] = useState('Shop');
  const [selectedCategory, setSelectedCategory] = useState('All Clothing');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState(5000);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('featured');

  // Modals state
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [legalModalConfig, setLegalModalConfig] = useState<{ isOpen: boolean; policy?: 'privacy' | 'terms' | 'shipping' | 'returns' | 'cookies' | 'grievance' }>({ isOpen: false });

  // Fetch products and store settings from backend API
  const [storeSettings, setStoreSettings] = useState<any>({});

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data) && data.length > 0) {
          setProductsList(data);
        }
      })
      .catch(err => console.log('Using local catalog fallback:', err));

    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data) setStoreSettings(data);
      })
      .catch(err => console.log('Using default settings:', err));
  }, []);

  // Persistence for wishlist and cart
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('nexora_wishlist');
      return saved ? JSON.parse(saved) : ['1', '2'];
    } catch {
      return ['1', '2'];
    }
  });

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('nexora_cart');
      return saved ? JSON.parse(saved) : [
        {
          cartId: 'item-1',
          product: PRODUCTS[0],
          size: 'M',
          color: '#556B2F',
          quantity: 1
        }
      ];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('nexora_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error(e);
    }
  }, [wishlistIds]);

  useEffect(() => {
    try {
      localStorage.setItem('nexora_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error(e);
    }
  }, [cartItems]);

  const handleSelectCategory = (cat: string) => {
    setSelectedCategory(cat);
    if (cat === 'All Clothing') {
      setSelectedCategories([]);
    } else if (cat === 'New Arrivals') {
      setSortBy('newest');
    } else {
      setSelectedCategories([cat]);
    }
  };

  const handleToggleCategory = (cat: string) => {
    setSelectedCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };

  const handleToggleSize = (size: string) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  const handleToggleColor = (colorName: string) => {
    setSelectedColors((prev) =>
      prev.includes(colorName) ? prev.filter((c) => c !== colorName) : [...prev, colorName]
    );
  };

  const handleClearAllFilters = () => {
    setSelectedCategories([]);
    setSelectedSizes([]);
    setSelectedColors([]);
    setPriceRange(5000);
    setSearchQuery('');
    setSelectedCategory('All Clothing');
  };

  const handleToggleWishlist = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    setWishlistIds((prev) =>
      prev.includes(product.id) ? prev.filter((id) => id !== product.id) : [...prev, product.id]
    );
  };

  const handleRemoveWishlistProduct = (product: Product) => {
    setWishlistIds((prev) => prev.filter((id) => id !== product.id));
  };

  const handleAddToCart = (product: Product, size: string, color: string, qty: number) => {
    const cartId = `${product.id}-${size}-${color}`;
    setCartItems((prev) => {
      const existing = prev.find((item) => item.cartId === cartId);
      if (existing) {
        return prev.map((item) =>
          item.cartId === cartId ? { ...item, quantity: item.quantity + qty } : item
        );
      }
      return [...prev, { cartId, product, size, color, quantity: qty }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (cartId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.cartId === cartId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (cartId: string) => {
    setCartItems((prev) => prev.filter((item) => item.cartId !== cartId));
  };

  const handleOrderComplete = () => {
    setCartItems([]);
  };

  const filteredProducts = useMemo(() => {
    return productsList.filter((p) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = p.name.toLowerCase().includes(q);
        const matchCategory = p.category.toLowerCase().includes(q);
        const matchDesc = p.description.toLowerCase().includes(q);
        if (!matchName && !matchCategory && !matchDesc) return false;
      }

      if (selectedCategories.length > 0 && !selectedCategories.includes(p.category)) {
        return false;
      }

      if (selectedSizes.length > 0 && !p.sizes.some((sz) => selectedSizes.includes(sz))) {
        return false;
      }

      if (p.price > priceRange) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'newest') return (b.badge === 'NEW' ? 1 : 0) - (a.badge === 'NEW' ? 1 : 0);
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      return 0;
    });
  }, [productsList, searchQuery, selectedCategories, selectedSizes, priceRange, sortBy]);

  const wishlistProducts = useMemo(() => {
    return productsList.filter((p) => wishlistIds.includes(p.id));
  }, [productsList, wishlistIds]);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#F8F6F2] text-[#171717] font-sans selection:bg-[#171717] selection:text-white flex flex-col justify-between">
      <div>
        {/* Header */}
        <Header
          cartCount={totalCartCount}
          wishlistCount={wishlistIds.length}
          onOpenCart={() => setIsCartOpen(true)}
          onOpenWishlist={() => setIsWishlistOpen(true)}
          onOpenAccount={() => setIsAccountOpen(true)}
          onOpenSupport={() => setIsSupportOpen(true)}
          onOpenAdmin={() => setIsAdminOpen(true)}
          activeNav={activeNav}
          onSelectNav={(nav) => {
            setActiveNav(nav);
            if (nav === 'New Arrivals') {
              setSortBy('newest');
              setSelectedCategory('New Arrivals');
            } else if (nav === 'T-Shirts') {
              handleSelectCategory('T-Shirts');
            } else if (nav === 'Shirts') {
              handleSelectCategory('Shirts');
            } else if (nav === 'Trousers') {
              handleSelectCategory('Trousers');
            } else if (nav === 'Home' || nav === 'Shop' || nav === 'Collections') {
              handleSelectCategory('All Clothing');
            }
          }}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />

        {/* Hero Banner */}
        <Hero
          onExplore={() => {
            const el = document.getElementById('shop-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onDiscoverEdit={() => {
            setSortBy('newest');
            const el = document.getElementById('shop-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          storeSettings={storeSettings}
        />

        {/* Category Pills */}
        <CategoryNav
          selectedCategory={selectedCategory}
          onSelectCategory={handleSelectCategory}
        />

        {/* Main Shopping Layout */}
        <main id="shop-section" className="px-6 lg:px-12 pb-16">
          <div className="flex flex-col lg:flex-row items-start gap-8">
            {/* Left Filter Sidebar */}
            <FilterSidebar
              selectedCategories={selectedCategories}
              onToggleCategory={handleToggleCategory}
              selectedSizes={selectedSizes}
              onToggleSize={handleToggleSize}
              selectedColors={selectedColors}
              onToggleColor={handleToggleColor}
              priceRange={priceRange}
              onPriceChange={setPriceRange}
              onClearAll={handleClearAllFilters}
              isOpenMobile={isMobileFiltersOpen}
              onCloseMobile={() => setIsMobileFiltersOpen(false)}
            />

            {/* Right Product Collection Area */}
            <div className="flex-1 w-full">
              <ProductToolbar
                totalCount={filteredProducts.length}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                sortBy={sortBy}
                onSortChange={setSortBy}
                onOpenMobileFilters={() => setIsMobileFiltersOpen(true)}
              />

              <ProductGrid
                products={filteredProducts}
                wishlistIds={wishlistIds}
                onToggleWishlist={handleToggleWishlist}
                onSelectProduct={(product) => setSelectedProduct(product)}
              />
            </div>
          </div>
        </main>

        {/* Bottom Benefits Strip */}
        <BenefitsStrip />
      </div>

      {/* Footer */}
      <Footer
        onOpenLegal={(policy) => setLegalModalConfig({ isOpen: true, policy })}
        onOpenSupport={() => setIsSupportOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Modals & Drawers */}
      {isAdminOpen && (
        <AdminPanel onClose={() => setIsAdminOpen(false)} />
      )}

      <CustomerAccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
      />

      <CustomerSupportModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
      />

      <LegalPolicyModal
        isOpen={legalModalConfig.isOpen}
        initialPolicy={legalModalConfig.policy}
        onClose={() => setLegalModalConfig({ isOpen: false })}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      <WishlistModal
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistProducts={wishlistProducts}
        onRemoveWishlist={handleRemoveWishlistProduct}
        onAddToCart={handleAddToCart}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        onOrderComplete={handleOrderComplete}
      />
    </div>
  );
}
