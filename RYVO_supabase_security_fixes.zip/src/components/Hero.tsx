import React from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';

interface HeroProps {
  onExplore: () => void;
  onDiscoverEdit: () => void;
  storeSettings?: any;
}

export const Hero: React.FC<HeroProps> = ({ onExplore, onDiscoverEdit, storeSettings }) => {
  const heroTitle = storeSettings?.heroTitle || 'EVERYDAY,\nELEVATED.';
  const heroSubtitle = storeSettings?.heroSubtitle || 'Timeless essentials. Modern silhouettes. Effortless style.';
  const heroBadge = storeSettings?.heroBadge || 'RYVO NEW COLLECTION';
  const heroImage = storeSettings?.heroImage || '/src/assets/images/hero_rail_clothing_1793263932773.jpg';

  return (
    <div className="px-6 lg:px-12 py-6 bg-transparent">
      <div className="relative rounded-xl overflow-hidden shadow-lg flex flex-col lg:flex-row items-stretch min-h-[360px] lg:h-[420px] bg-transparent">
        {/* Background Image filling the entire hero banner */}
        <div className="absolute inset-0 z-0">
          <img
            src={heroImage}
            alt="RYVO clothing rail collection"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          {/* Transparent gradient overlay to make text pop while keeping background image visible */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
        </div>

        {/* Left Side Content Overlaid Transparently on Image */}
        <div className="relative z-10 flex-1 p-8 lg:p-14 flex flex-col justify-center max-w-xl text-white">
          <div className="text-[11px] font-semibold tracking-[0.2em] text-white/80 uppercase mb-3 drop-shadow">
            {heroBadge} &bull;
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-[48px] font-bold text-white tracking-tight leading-[1.1] mb-4 drop-shadow-md whitespace-pre-line">
            {heroTitle}
          </h1>
          <p className="text-xs sm:text-sm text-white/90 mb-8 max-w-sm leading-relaxed drop-shadow">
            {heroSubtitle}
          </p>
          <div className="flex flex-wrap items-center gap-6">
            <button
              onClick={onExplore}
              className="bg-white text-[#171717] text-xs font-semibold px-6 py-3.5 rounded hover:bg-white/90 transition-colors flex items-center gap-2 shadow-md"
            >
              EXPLORE COLLECTION →
            </button>
            <button
              onClick={onDiscoverEdit}
              className="text-xs font-semibold text-white hover:text-white/80 transition-colors underline underline-offset-4 drop-shadow"
            >
              DISCOVER THE EDIT
            </button>
          </div>
        </div>

        {/* Far-Right Collection Indicator */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 z-10 hidden xl:flex flex-col items-center justify-center gap-2 bg-black/40 backdrop-blur-md px-2 py-3 rounded-md text-white text-[10px] font-mono shadow-md border border-white/10">
          <button className="hover:text-white/70 transition-colors">
            <ChevronUp size={14} />
          </button>
          <span className="font-semibold tracking-wider">01</span>
          <div className="w-3 h-[1px] bg-white/50" />
          <span className="text-white/70">04</span>
          <button className="hover:text-white/70 transition-colors">
            <ChevronDown size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
