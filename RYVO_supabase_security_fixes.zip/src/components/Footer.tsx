import React from 'react';

interface FooterProps {
  onOpenLegal: (policy: 'privacy' | 'terms' | 'shipping' | 'returns' | 'cookies' | 'grievance') => void;
  onOpenSupport: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal, onOpenSupport, onOpenAdmin }) => {
  return (
    <footer className="bg-[#171717] text-[#F8F6F2] px-6 lg:px-12 py-16">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
        {/* Col 1 */}
        <div className="flex flex-col gap-4">
          <span className="text-xl font-bold tracking-[0.25em] text-white">
            N E X O R A
          </span>
          <p className="text-xs text-[#A39E93] leading-relaxed max-w-xs">
            Everyday, elevated. Premium menswear and contemporary wardrobe essentials crafted with meticulous attention to detail and enduring silhouettes.
          </p>
          <button
            onClick={onOpenAdmin}
            className="text-[11px] font-mono text-[#A39E93] hover:text-white underline text-left w-fit mt-2"
          >
            &rarr; Admin Control Center
          </button>
        </div>

        {/* Col 2 */}
        <div className="flex flex-col gap-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-white">Shop</h4>
          <a href="#shop" className="text-xs text-[#A39E93] hover:text-white transition-colors">T-Shirts & Hoodies</a>
          <a href="#shop" className="text-xs text-[#A39E93] hover:text-white transition-colors">Shirts & Overshirts</a>
          <a href="#shop" className="text-xs text-[#A39E93] hover:text-white transition-colors">Trousers & Chinos</a>
          <a href="#shop" className="text-xs text-[#A39E93] hover:text-white transition-colors">Denim & Jackets</a>
          <a href="#shop" className="text-xs text-[#A39E93] hover:text-white transition-colors">New Arrivals</a>
        </div>

        {/* Col 3 */}
        <div className="flex flex-col gap-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-white">Client Care &amp; Legal</h4>
          <button onClick={onOpenSupport} className="text-xs text-[#A39E93] hover:text-white transition-colors text-left">Contact &amp; Support</button>
          <button onClick={() => onOpenLegal('shipping')} className="text-xs text-[#A39E93] hover:text-white transition-colors text-left">Shipping Policy</button>
          <button onClick={() => onOpenLegal('returns')} className="text-xs text-[#A39E93] hover:text-white transition-colors text-left">Returns &amp; Refunds</button>
          <button onClick={() => onOpenLegal('privacy')} className="text-xs text-[#A39E93] hover:text-white transition-colors text-left">Privacy Policy (DPDP Act)</button>
          <button onClick={() => onOpenLegal('grievance')} className="text-xs text-[#A39E93] hover:text-white transition-colors text-left">Grievance Redressal</button>
        </div>

        {/* Col 4 */}
        <div className="flex flex-col gap-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-white">Newsletter</h4>
          <p className="text-xs text-[#A39E93]">
            Subscribe to receive updates on new collections and private releases.
          </p>
          <div className="flex items-center gap-2 mt-2">
            <input
              type="email"
              placeholder="Enter your email"
              className="bg-[#262626] border border-[#383838] rounded px-3 py-2 text-xs text-white placeholder-[#77736D] focus:outline-none focus:border-white flex-1"
            />
            <button
              onClick={() => alert('Thank you for subscribing to NEXORA.')}
              className="bg-white text-[#171717] px-4 py-2 rounded text-xs font-bold hover:bg-[#E0DDD5] transition-colors"
            >
              Join
            </button>
          </div>
        </div>
      </div>

      <div className="pt-8 border-t border-[#262626] max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between text-xs text-[#A39E93] gap-4">
        <span>&copy; {new Date().getFullYear()} NEXORA Apparel Private Limited. All rights reserved.</span>
        <div className="flex items-center gap-6">
          <button onClick={() => onOpenLegal('privacy')} className="hover:text-white transition-colors">Privacy Policy</button>
          <button onClick={() => onOpenLegal('terms')} className="hover:text-white transition-colors">Terms of Service</button>
          <button onClick={() => onOpenLegal('cookies')} className="hover:text-white transition-colors">Cookie Policy</button>
        </div>
      </div>
    </footer>
  );
};
