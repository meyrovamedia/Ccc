import React from 'react';
import { Product } from '../data/products';
import { Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onSelectProduct
}) => {
  return (
    <div
      onClick={() => onSelectProduct(product)}
      className="group cursor-pointer flex flex-col bg-transparent"
    >
      {/* Image Container */}
      <div className="relative aspect-[4/3] bg-[#E7E4DF] rounded overflow-hidden mb-3">
        {product.badge && (
          <span className="absolute top-3 left-3 bg-[#171717] text-white text-[9px] font-bold tracking-widest uppercase px-2 py-1 rounded shadow-sm z-10">
            {product.badge}
          </span>
        )}
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />

        {/* Wishlist Heart Icon */}
        <button
          onClick={(e) => onToggleWishlist(product, e)}
          className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center text-[#171717] hover:bg-white shadow-sm transition-transform active:scale-95"
          title="Wishlist"
        >
          <Heart
            size={16}
            className={isWishlisted ? 'fill-[#171717] text-[#171717]' : 'text-[#171717]'}
            strokeWidth={1.5}
          />
        </button>
      </div>

      {/* Product Details */}
      <div className="flex flex-col gap-1.5 px-0.5">
        <h3 className="text-xs sm:text-sm font-semibold text-[#171717] group-hover:text-[#77736D] transition-colors truncate">
          {product.name}
        </h3>
        <div className="flex items-center justify-between">
          <span className="text-xs sm:text-sm font-mono font-medium text-[#171717]">
            ₹{product.price.toLocaleString()}
          </span>

          {/* Color swatches */}
          <div className="flex items-center gap-1">
            {product.colors.slice(0, 4).map((c, i) => (
              <span
                key={i}
                className="w-3 h-3 rounded-full border border-[#E8E4DE]"
                style={{ backgroundColor: c }}
              />
            ))}
            {product.colors.length > 4 && (
              <span className="text-[9px] text-[#77736D] font-mono">+{product.colors.length - 4}</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
