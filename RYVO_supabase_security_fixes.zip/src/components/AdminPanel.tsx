import React, { useState, useEffect } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabaseBrowser } from '../lib/supabase';
import { 
  LayoutDashboard, Package, ShoppingCart, Users, Tag, Settings as SettingsIcon, 
  FileText, ShieldAlert, Plus, Edit, Trash2, CheckCircle, Clock, Truck, ArrowLeft, RefreshCw 
} from 'lucide-react';

interface AdminPanelProps {
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'products' | 'orders' | 'customers' | 'coupons' | 'logs' | 'settings'>('dashboard');
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [authBusy, setAuthBusy] = useState(false);

  useEffect(() => {
    if (!supabaseBrowser) { setAuthReady(true); return; }
    supabaseBrowser.auth.getSession().then(({ data }) => { setSession(data.session); setAuthReady(true); });
    const { data: listener } = supabaseBrowser.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  const authorizedFetch = async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const activeSession = session || (await supabaseBrowser?.auth.getSession())?.data.session;
    if (!activeSession) throw new Error('Please sign in with an administrator account.');
    const headers = new Headers(init.headers || {});
    headers.set('Authorization', `Bearer ${activeSession.access_token}`);
    return fetch(input, { ...init, headers });
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault(); setAuthError(''); setAuthBusy(true);
    if (!supabaseBrowser) { setAuthError('Supabase browser configuration is missing.'); setAuthBusy(false); return; }
    const { error } = await supabaseBrowser.auth.signInWithPassword({ email: loginEmail.trim(), password: loginPassword });
    if (error) setAuthError(error.message);
    setAuthBusy(false);
  };

  const handleAdminLogout = async () => { await supabaseBrowser?.auth.signOut(); setSession(null); };
  
  const [analytics, setAnalytics] = useState<any>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [coupons, setCoupons] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({});
  const [settingsForm, setSettingsForm] = useState({
    storeName: 'RYVO',
    supportEmail: '',
    legalBusinessName: '',
    businessAddress: '',
    gstin: '',
    grievanceOfficer: '',
    heroTitle: 'EVERYDAY,\nELEVATED.',
    heroSubtitle: 'Timeless essentials. Modern silhouettes. Effortless style.',
    heroBadge: 'RYVO NEW COLLECTION',
    heroImage: '/src/assets/images/hero_rail_clothing_1793263932773.jpg',
    bestSellersTitle: 'FEATURED BESTSELLERS'
  });

  useEffect(() => {
    if (settings) {
      setSettingsForm({
        storeName: settings.storeName || 'RYVO',
        supportEmail: settings.supportEmail || '',
        legalBusinessName: settings.legalBusinessName || '',
        businessAddress: settings.businessAddress || '',
        gstin: settings.gstin || '',
        grievanceOfficer: settings.grievanceOfficer || '',
        heroTitle: settings.heroTitle || 'EVERYDAY,\nELEVATED.',
        heroSubtitle: settings.heroSubtitle || 'Timeless essentials. Modern silhouettes. Effortless style.',
        heroBadge: settings.heroBadge || 'RYVO NEW COLLECTION',
        heroImage: settings.heroImage || '/src/assets/images/hero_rail_clothing_1793263932773.jpg',
        bestSellersTitle: settings.bestSellersTitle || 'FEATURED BESTSELLERS'
      });
    }
  }, [settings]);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const response = await authorizedFetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settingsForm)
    });
    if (!response.ok) { alert('Settings could not be saved. Please sign in again or check server permissions.'); return; }
    alert('Store settings, Hero section, and CMS banners updated successfully!');
    fetchData();
  };

  const [loading, setLoading] = useState(false);

  // New product form state
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    category: 'T-Shirts',
    price: 1990,
    stock: 50,
    image: '/src/assets/images/product_white_tshirt_1793263932650.jpg',
    images: [] as string[],
    video: '',
    description: '',
    badge: 'NEW'
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [resAna, resProd, resOrd, resCust, resCoup, resLog, resSet] = await Promise.all([
        authorizedFetch('/api/analytics').then(r => r.json()).catch(() => null),
        authorizedFetch('/api/products').then(r => r.json()).catch(() => []),
        authorizedFetch('/api/orders').then(r => r.json()).catch(() => []),
        authorizedFetch('/api/customers').then(r => r.json()).catch(() => []),
        authorizedFetch('/api/coupons').then(r => r.json()).catch(() => []),
        authorizedFetch('/api/logs').then(r => r.json()).catch(() => []),
        authorizedFetch('/api/admin/settings').then(r => r.json()).catch(() => ({}))
      ]);
      setAnalytics(resAna || { grossSales: 0, totalOrders: 0, pendingOrders: 0, shippedOrders: 0, deliveredOrders: 0, lowStockProducts: 0, totalProducts: 0, totalCustomers: 0 });
      setProducts(Array.isArray(resProd) ? resProd : []);
      setOrders(Array.isArray(resOrd) ? resOrd : []);
      setCustomers(Array.isArray(resCust) ? resCust : []);
      setCoupons(Array.isArray(resCoup) ? resCoup : []);
      setLogs(Array.isArray(resLog) ? resLog : []);
      setSettings(resSet || {});
    } catch (e) {
      console.error(e);
      setAnalytics({ grossSales: 0, totalOrders: 0, pendingOrders: 0, shippedOrders: 0, deliveredOrders: 0, lowStockProducts: 0, totalProducts: 0, totalCustomers: 0 });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session) fetchData();
  }, [session]);

  const handleHeroImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setSettingsForm(prev => ({ ...prev, heroImage: uploadEvent.target?.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const handleProductMainImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const res = uploadEvent.target?.result as string;
      setNewProduct(prev => ({ ...prev, image: res }));
    };
    reader.readAsDataURL(file);
  };

  const handleProductGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const newImages: string[] = [];
    let loadedCount = 0;
    Array.from(files).slice(0, 5).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (ev.target?.result) {
          newImages.push(ev.target.result as string);
        }
        loadedCount++;
        if (loadedCount === Math.min(files.length, 5)) {
          setNewProduct(prev => ({ ...prev, images: [...(prev.images || []), ...newImages].slice(0, 5) }));
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleProductVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const res = uploadEvent.target?.result as string;
      setNewProduct(prev => ({ ...prev, video: res }));
    };
    reader.readAsDataURL(file);
  };

  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    await authorizedFetch(`/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    fetchData();
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    await authorizedFetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...newProduct,
        colors: ['#171717', '#FFFFFF', '#808080'],
        sizes: ['S', 'M', 'L', 'XL'],
        rating: 5.0,
        reviewsCount: 1
      })
    });
    setShowAddProduct(false);
    fetchData();
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    await authorizedFetch(`/api/products/${id}`, { method: 'DELETE' });
    fetchData();
  };

  const handleMarkOutOfStock = async (id: string) => {
    await authorizedFetch(`/api/products/${id}/stock`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stock: 0 })
    });
    fetchData();
  };

  if (!authReady) {
    return <div className="fixed inset-0 z-50 bg-[#F8F6F2] grid place-items-center text-sm text-[#77736D]">Checking administrator session…</div>;
  }

  if (!session) {
    return (
      <div className="fixed inset-0 z-50 bg-[#F8F6F2] grid place-items-center p-6">
        <form onSubmit={handleAdminLogin} className="w-full max-w-md bg-white border border-[#E8E4DE] p-8 rounded shadow-sm">
          <div className="text-[11px] tracking-[0.25em] text-[#77736D] uppercase mb-3">RYVO Administration</div>
          <h1 className="text-xl font-bold text-[#171717] mb-2">Administrator sign in</h1>
          <p className="text-xs text-[#77736D] mb-6">Use an approved Supabase Auth account. Only addresses listed in the server’s ADMIN_EMAILS setting can enter.</p>
          {!supabaseBrowser && <p className="text-xs text-red-700 mb-4">Supabase browser settings are missing. Configure VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY.</p>}
          <label className="block text-xs text-[#77736D] mb-2">Email</label>
          <input type="email" required value={loginEmail} onChange={e => setLoginEmail(e.target.value)} className="w-full border border-[#D8D3CB] px-3 py-3 mb-4 text-sm" autoComplete="username" />
          <label className="block text-xs text-[#77736D] mb-2">Password</label>
          <input type="password" required value={loginPassword} onChange={e => setLoginPassword(e.target.value)} className="w-full border border-[#D8D3CB] px-3 py-3 mb-4 text-sm" autoComplete="current-password" />
          {authError && <p role="alert" className="text-xs text-red-700 mb-4">{authError}</p>}
          <button disabled={!supabaseBrowser || authBusy} className="w-full bg-[#171717] text-white py-3 text-xs uppercase tracking-widest disabled:opacity-50">{authBusy ? 'Signing in…' : 'Sign in securely'}</button>
          <button type="button" onClick={onClose} className="w-full mt-3 py-2 text-xs text-[#77736D]">Return to store</button>
        </form>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-[#F8F6F2] flex flex-col overflow-hidden">
      {/* Top Bar */}
      <header className="bg-[#171717] text-white px-6 py-4 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex items-center gap-2 text-xs text-[#A39E93] hover:text-white transition-colors"
          >
            <ArrowLeft size={16} /> Exit Admin
          </button>
          <span className="text-[#383838]">|</span>
          <h1 className="text-sm font-bold tracking-[0.2em] uppercase">RYVO Admin Control Center</h1>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <span className="text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> Secure Backend Active
          </span>
          <button onClick={handleAdminLogout} className="text-[10px] uppercase tracking-widest text-[#D6D0C5] hover:text-white">Sign out</button>
          <button
            onClick={fetchData}
            className="p-1.5 bg-[#262626] hover:bg-[#383838] rounded text-white transition-colors"
            title="Refresh Data"
          >
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </header>

      {/* Main Content Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-[#E8E4DE] p-4 flex flex-col gap-1 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'products', label: 'Product Catalog', icon: Package },
            { id: 'orders', label: 'Order Management', icon: ShoppingCart },
            { id: 'customers', label: 'Customer Accounts', icon: Users },
            { id: 'coupons', label: 'Coupons & Promos', icon: Tag },
            { id: 'logs', label: 'Activity Audit Log', icon: ShieldAlert },
            { id: 'settings', label: 'Store Settings & Legal', icon: SettingsIcon }
          ].map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded text-xs font-medium transition-colors ${
                  active ? 'bg-[#171717] text-white' : 'text-[#77736D] hover:bg-[#F0EEEA] hover:text-[#171717]'
                }`}
              >
                <Icon size={16} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-8 bg-[#F8F6F2]">
          
          {/* DASHBOARD TAB */}
          {activeTab === 'dashboard' && analytics && (
            <div className="flex flex-col gap-8 max-w-6xl mx-auto">
              <div>
                <h2 className="text-xl font-bold text-[#171717]">Dashboard Overview</h2>
                <p className="text-xs text-[#77736D]">Real-time business performance and metrics.</p>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded border border-[#E8E4DE] shadow-xs">
                  <span className="text-[11px] font-mono uppercase text-[#77736D] block mb-1">Gross Sales</span>
                  <div className="text-2xl font-bold font-mono text-[#171717]">₹{(analytics?.grossSales ?? 0).toLocaleString()}</div>
                  <span className="text-[10px] text-emerald-700 mt-1 block font-medium">+12.4% vs last month</span>
                </div>
                <div className="bg-white p-5 rounded border border-[#E8E4DE] shadow-xs">
                  <span className="text-[11px] font-mono uppercase text-[#77736D] block mb-1">Total Orders</span>
                  <div className="text-2xl font-bold font-mono text-[#171717]">{analytics.totalOrders}</div>
                  <span className="text-[10px] text-[#77736D] mt-1 block font-medium">Pending fulfillment: {analytics.pendingOrders}</span>
                </div>
                <div className="bg-white p-5 rounded border border-[#E8E4DE] shadow-xs">
                  <span className="text-[11px] font-mono uppercase text-[#77736D] block mb-1">Active Customers</span>
                  <div className="text-2xl font-bold font-mono text-[#171717]">{analytics.totalCustomers}</div>
                  <span className="text-[10px] text-emerald-700 mt-1 block font-medium">Registered in DB</span>
                </div>
                <div className="bg-white p-5 rounded border border-[#E8E4DE] shadow-xs">
                  <span className="text-[11px] font-mono uppercase text-[#77736D] block mb-1">Low Stock Alerts</span>
                  <div className="text-2xl font-bold font-mono text-[#171717] text-amber-700">{analytics.lowStockProducts}</div>
                  <span className="text-[10px] text-[#77736D] mt-1 block font-medium">Products &lt; 20 units</span>
                </div>
              </div>

              {/* Recent Orders Section */}
              <div className="bg-white rounded border border-[#E8E4DE] p-6">
                <h3 className="text-xs font-bold uppercase tracking-wider mb-4 text-[#171717]">Recent Customer Orders</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-[#E8E4DE] text-[#77736D] font-mono">
                        <th className="pb-3">Order ID</th>
                        <th className="pb-3">Customer</th>
                        <th className="pb-3">Status</th>
                        <th className="pb-3">Total</th>
                        <th className="pb-3">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E8E4DE]">
                      {orders.slice(0, 5).map((o) => (
                        <tr key={o.id} className="hover:bg-[#F8F6F2]">
                          <td className="py-3 font-mono font-semibold">{o.id}</td>
                          <td className="py-3">{o.customerName}</td>
                          <td className="py-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${
                              o.status === 'Delivered' ? 'bg-emerald-100 text-emerald-800' :
                              o.status === 'Shipped' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {o.status}
                            </span>
                          </td>
                          <td className="py-3 font-mono">₹{(o?.total ?? 0).toLocaleString()}</td>
                          <td className="py-3 text-[#77736D]">{new Date(o.createdAt).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* PRODUCTS TAB */}
          {activeTab === 'products' && (
            <div className="flex flex-col gap-6 max-w-6xl mx-auto">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-[#171717]">Product Catalog ({products.length})</h2>
                  <p className="text-xs text-[#77736D]">Manage inventory, pricing, and active listings.</p>
                </div>
                <button
                  onClick={() => setShowAddProduct(true)}
                  className="bg-[#171717] text-white text-xs font-medium px-4 py-2 rounded hover:bg-[#333333] transition-colors flex items-center gap-2"
                >
                  <Plus size={14} /> Add New Product
                </button>
              </div>

              {showAddProduct && (
                <div className="bg-white p-6 rounded border border-[#E8E4DE] shadow-md animate-fadeIn">
                  <h3 className="text-xs font-bold uppercase tracking-wider mb-4">Add Product to Catalog</h3>
                  <form onSubmit={handleCreateProduct} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-[11px] text-[#77736D] block mb-1">Product Name</label>
                      <input
                        type="text"
                        required
                        value={newProduct.name}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                        className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-[#77736D] block mb-1">Category</label>
                      <select
                        value={newProduct.category}
                        onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                        className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                      >
                        <option value="T-Shirts">T-Shirts</option>
                        <option value="Shirts">Shirts</option>
                        <option value="Overshirts">Overshirts</option>
                        <option value="Trousers">Trousers</option>
                        <option value="Jeans">Jeans</option>
                        <option value="Jackets">Jackets</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[11px] text-[#77736D] block mb-1">Price (₹)</label>
                      <input
                        type="number"
                        required
                        value={newProduct.price}
                        onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                        className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-[#77736D] block mb-1">Stock Quantity</label>
                      <input
                        type="number"
                        required
                        value={newProduct.stock}
                        onChange={(e) => setNewProduct({ ...newProduct, stock: Number(e.target.value) })}
                        className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2 font-mono"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="text-[11px] text-[#77736D] block mb-1">Description</label>
                      <input
                        type="text"
                        required
                        value={newProduct.description}
                        onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                        className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                      />
                    </div>
                    <div className="sm:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-[#E8E4DE]">
                      <div>
                        <label className="text-[11px] text-[#77736D] block mb-1">Primary Product Image (JPG/PNG)</label>
                        <input
                          type="file"
                          accept="image/png, image/jpeg, image/jpg"
                          onChange={handleProductMainImageUpload}
                          className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs p-1"
                        />
                        {newProduct.image && (
                          <div className="mt-2 w-12 h-12 rounded overflow-hidden border border-[#E8E4DE]">
                            <img src={newProduct.image} alt="Primary" className="w-full h-full object-cover" />
                          </div>
                        )}
                      </div>
                      <div>
                        <label className="text-[11px] text-[#77736D] block mb-1">Gallery Images (Up to 4-5 Images)</label>
                        <input
                          type="file"
                          accept="image/png, image/jpeg, image/jpg"
                          multiple
                          onChange={handleProductGalleryUpload}
                          className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs p-1"
                        />
                        {newProduct.images && newProduct.images.length > 0 && (
                          <div className="mt-2 flex items-center gap-1 overflow-x-auto">
                            {newProduct.images.map((img, i) => (
                              <img key={i} src={img} alt={`gal-${i}`} className="w-8 h-8 rounded object-cover border border-[#E8E4DE]" />
                            ))}
                          </div>
                        )}
                      </div>
                      <div>
                        <label className="text-[11px] text-[#77736D] block mb-1">Product Video (MP4/WebM)</label>
                        <input
                          type="file"
                          accept="video/mp4, video/webm"
                          onChange={handleProductVideoUpload}
                          className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs p-1"
                        />
                        {newProduct.video && (
                          <span className="text-[10px] text-emerald-700 font-medium block mt-1">✓ Video uploaded</span>
                        )}
                      </div>
                    </div>
                    <div className="sm:col-span-3 flex justify-end gap-2 mt-2">
                      <button
                        type="button"
                        onClick={() => setShowAddProduct(false)}
                        className="px-4 py-2 text-xs border border-[#E8E4DE] rounded hover:bg-[#F0EEEA]"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-2 text-xs bg-[#171717] text-white rounded hover:bg-[#333333]"
                      >
                        Save Product
                      </button>
                    </div>
                  </form>
                </div>
              )}

              <div className="bg-white rounded border border-[#E8E4DE] overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-[#F0EEEA] border-b border-[#E8E4DE] font-mono text-[#77736D]">
                      <th className="p-3">Product</th>
                      <th className="p-3">Category</th>
                      <th className="p-3">Price</th>
                      <th className="p-3">Stock</th>
                      <th className="p-3">Badge</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E8E4DE]">
                    {products.map((p) => (
                      <tr key={p.id} className="hover:bg-[#F8F6F2]">
                        <td className="p-3 flex items-center gap-3">
                          <img src={p.image} alt={p.name} className="w-10 h-10 object-cover rounded bg-[#E7E4DF]" />
                          <span className="font-semibold text-[#171717]">{p.name}</span>
                        </td>
                        <td className="p-3 text-[#77736D]">{p.category}</td>
                        <td className="p-3 font-mono">₹{(p?.price ?? 0).toLocaleString()}</td>
                        <td className="p-3 font-mono">
                          <span className={p.stock < 20 ? 'text-amber-700 font-bold' : ''}>{p.stock} units</span>
                        </td>
                        <td className="p-3">
                          {p.badge && <span className="bg-[#171717] text-white text-[9px] px-2 py-0.5 rounded">{p.badge}</span>}
                        </td>
                        <td className="p-3 text-right flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleMarkOutOfStock(p.id)}
                            className="px-2 py-1 bg-amber-50 text-amber-800 hover:bg-amber-100 rounded text-[11px] font-medium transition-colors"
                            title="Set stock to 0 (Out of stock)"
                          >
                            Out of Stock
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-1.5 text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="Delete product"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ORDERS TAB */}
          {activeTab === 'orders' && (
            <div className="flex flex-col gap-6 max-w-6xl mx-auto">
              <div>
                <h2 className="text-xl font-bold text-[#171717]">Order Management ({orders.length})</h2>
                <p className="text-xs text-[#77736D]">Review customer orders, update tracking status, and manage fulfillment.</p>
              </div>

              <div className="bg-white rounded border border-[#E8E4DE] overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-[#F0EEEA] border-b border-[#E8E4DE] font-mono text-[#77736D]">
                      <th className="p-3">Order ID</th>
                      <th className="p-3">Customer</th>
                      <th className="p-3">Items</th>
                      <th className="p-3">Total</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Tracking</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E8E4DE]">
                    {orders.map((o) => (
                      <tr key={o.id} className="hover:bg-[#F8F6F2]">
                        <td className="p-3 font-mono font-semibold">{o.id}</td>
                        <td className="p-3">
                          <div className="font-medium">{o.customerName}</div>
                          <div className="text-[10px] text-[#77736D]">{o.customerPhone}</div>
                        </td>
                        <td className="p-3 text-[#77736D]">
                          {o.items.map((it: any) => `${it.name} (x${it.quantity})`).join(', ')}
                        </td>
                        <td className="p-3 font-mono font-semibold">₹{(o?.total ?? 0).toLocaleString()}</td>
                        <td className="p-3">
                          <select
                            value={o.status}
                            onChange={(e) => handleUpdateOrderStatus(o.id, e.target.value)}
                            className="bg-[#F8F6F2] border border-[#E8E4DE] rounded px-2 py-1 text-xs font-medium cursor-pointer"
                          >
                            <option value="Confirmed">Confirmed</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </td>
                        <td className="p-3 font-mono text-[11px] text-[#77736D]">{o.trackingNumber}</td>
                        <td className="p-3 text-right font-mono text-[11px] text-[#77736D]">
                          {new Date(o.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* CUSTOMERS TAB */}
          {activeTab === 'customers' && (
            <div className="flex flex-col gap-6 max-w-6xl mx-auto">
              <div>
                <h2 className="text-xl font-bold text-[#171717]">Customer Accounts ({customers.length})</h2>
                <p className="text-xs text-[#77736D]">Registered customer accounts and DPDP Act compliance directory.</p>
              </div>
              <div className="bg-white rounded border border-[#E8E4DE] overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-[#F0EEEA] border-b border-[#E8E4DE] font-mono text-[#77736D]">
                      <th className="p-3">Customer ID</th>
                      <th className="p-3">Name</th>
                      <th className="p-3">Email</th>
                      <th className="p-3">Phone</th>
                      <th className="p-3">Orders</th>
                      <th className="p-3">Total Spent</th>
                      <th className="p-3">Joined</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E8E4DE]">
                    {customers.map((c) => (
                      <tr key={c.id} className="hover:bg-[#F8F6F2]">
                        <td className="p-3 font-mono">{c.id}</td>
                        <td className="p-3 font-semibold">{c.name}</td>
                        <td className="p-3 text-[#77736D]">{c.email}</td>
                        <td className="p-3 font-mono text-[#77736D]">{c.phone}</td>
                        <td className="p-3 font-mono">{c.ordersCount}</td>
                        <td className="p-3 font-mono">₹{(c?.totalSpent ?? 0).toLocaleString()}</td>
                        <td className="p-3 text-[#77736D]">{c.joinedDate}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* COUPONS TAB */}
          {activeTab === 'coupons' && (
            <div className="flex flex-col gap-6 max-w-6xl mx-auto">
              <div>
                <h2 className="text-xl font-bold text-[#171717]">Coupons & Promotions</h2>
                <p className="text-xs text-[#77736D]">Active promotional discount codes.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {coupons.map((c) => (
                  <div key={c.id} className="bg-white p-5 rounded border border-[#E8E4DE] flex items-center justify-between">
                    <div>
                      <span className="text-xs font-mono font-bold tracking-widest bg-[#F0EEEA] px-2.5 py-1 rounded">
                        {c.code}
                      </span>
                      <div className="text-xs text-[#77736D] mt-2">
                        {c.discountPercent}% OFF on orders above ₹{(c?.minOrder ?? 0).toLocaleString()}
                      </div>
                    </div>
                    <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2 py-1 rounded">Active</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* LOGS TAB */}
          {activeTab === 'logs' && (
            <div className="flex flex-col gap-6 max-w-6xl mx-auto">
              <div>
                <h2 className="text-xl font-bold text-[#171717]">Administrative Activity Audit Log</h2>
                <p className="text-xs text-[#77736D]">Immutable record of administrative actions and updates.</p>
              </div>
              <div className="bg-white rounded border border-[#E8E4DE] overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-[#F0EEEA] border-b border-[#E8E4DE] font-mono text-[#77736D]">
                      <th className="p-3">Log ID</th>
                      <th className="p-3">Admin</th>
                      <th className="p-3">Action</th>
                      <th className="p-3">Target</th>
                      <th className="p-3">Timestamp</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E8E4DE]">
                    {logs.map((l) => (
                      <tr key={l.id} className="hover:bg-[#F8F6F2]">
                        <td className="p-3 font-mono">{l.id}</td>
                        <td className="p-3 text-[#77736D]">{l.admin}</td>
                        <td className="p-3 font-semibold text-[#171717]">{l.action}</td>
                        <td className="p-3 font-mono">{l.target}</td>
                        <td className="p-3 text-[#77736D] font-mono text-[11px]">{new Date(l.timestamp).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === 'settings' && (
            <div className="flex flex-col gap-6 max-w-3xl mx-auto">
              <div>
                <h2 className="text-xl font-bold text-[#171717]">Store Settings, Hero Banner & CMS</h2>
                <p className="text-xs text-[#77736D]">Update website banners, hero section, and store parameters without code updates.</p>
              </div>
              <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded border border-[#E8E4DE] flex flex-col gap-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#171717] border-b border-[#E8E4DE] pb-2">Hero Section & Banner CMS</h3>
                <div>
                  <label className="text-[11px] text-[#77736D] block mb-1">Hero Title (Use newline for multi-line)</label>
                  <textarea
                    value={settingsForm.heroTitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, heroTitle: e.target.value })}
                    className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2 font-bold"
                    rows={2}
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#77736D] block mb-1">Hero Subtitle / Description</label>
                  <input
                    type="text"
                    value={settingsForm.heroSubtitle}
                    onChange={(e) => setSettingsForm({ ...settingsForm, heroSubtitle: e.target.value })}
                    className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Hero Badge Text</label>
                    <input
                      type="text"
                      value={settingsForm.heroBadge}
                      onChange={(e) => setSettingsForm({ ...settingsForm, heroBadge: e.target.value })}
                      className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2 font-mono uppercase"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Hero Banner Image (Upload JPG/PNG)</label>
                    <input
                      type="file"
                      accept="image/png, image/jpeg, image/jpg"
                      onChange={handleHeroImageUpload}
                      className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs p-1"
                    />
                    {settingsForm.heroImage && (
                      <div className="mt-2 w-24 h-12 rounded overflow-hidden border border-[#E8E4DE]">
                        <img src={settingsForm.heroImage} alt="Hero preview" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>
                </div>

                <h3 className="text-xs font-bold uppercase tracking-wider text-[#171717] border-b border-[#E8E4DE] pb-2 pt-4">Store & Legal Parameters</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Store Name</label>
                    <input
                      type="text"
                      value={settingsForm.storeName}
                      onChange={(e) => setSettingsForm({ ...settingsForm, storeName: e.target.value })}
                      className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Support Email</label>
                    <input
                      type="email"
                      value={settingsForm.supportEmail}
                      onChange={(e) => setSettingsForm({ ...settingsForm, supportEmail: e.target.value })}
                      className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[11px] text-[#77736D] block mb-1">Legal Business Name</label>
                  <input
                    type="text"
                    value={settingsForm.legalBusinessName}
                    onChange={(e) => setSettingsForm({ ...settingsForm, legalBusinessName: e.target.value })}
                    className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#77736D] block mb-1">Registered Business Address</label>
                  <textarea
                    value={settingsForm.businessAddress}
                    onChange={(e) => setSettingsForm({ ...settingsForm, businessAddress: e.target.value })}
                    className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                    rows={2}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">GSTIN</label>
                    <input
                      type="text"
                      value={settingsForm.gstin}
                      onChange={(e) => setSettingsForm({ ...settingsForm, gstin: e.target.value })}
                      className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Grievance & Privacy Officer</label>
                    <input
                      type="text"
                      value={settingsForm.grievanceOfficer}
                      onChange={(e) => setSettingsForm({ ...settingsForm, grievanceOfficer: e.target.value })}
                      className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="mt-4 bg-[#171717] text-white text-xs font-bold uppercase tracking-wider py-3 rounded hover:bg-[#333333] transition-colors shadow-sm"
                >
                  Save Store Settings & Banner CMS
                </button>
              </form>
            </div>
          )}

        </main>
      </div>
    </div>
  );
};
