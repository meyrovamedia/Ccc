import React from 'react';
import { CATEGORIES } from '../data/products';

interface CategoryNavProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

export const CategoryNav: React.FC<CategoryNavProps> = ({
  selectedCategory,
  onSelectCategory
}) => {
  return (
    <div className="px-6 lg:px-12 pb-6 bg-[#F8F6F2]">
      <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => onSelectCategory(cat)}
              className={`px-5 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-all shadow-sm ${
                isActive
                  ? 'bg-[#171717] text-white'
                  : 'bg-[#F0EEEA] text-[#171717] hover:bg-[#E8E4DE]'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>
    </div>
  );
};
