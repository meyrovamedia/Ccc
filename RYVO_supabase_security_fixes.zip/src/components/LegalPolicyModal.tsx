import React, { useState } from 'react';
import { X, ShieldCheck, FileText, Truck, RotateCcw, Cookie, HelpCircle } from 'lucide-react';

interface LegalPolicyModalProps {
  isOpen: boolean;
  initialPolicy?: 'privacy' | 'terms' | 'shipping' | 'returns' | 'cookies' | 'grievance';
  onClose: () => void;
}

export const LegalPolicyModal: React.FC<LegalPolicyModalProps> = ({
  isOpen,
  initialPolicy = 'privacy',
  onClose
}) => {
  if (!isOpen) return null;

  const [policyType, setPolicyType] = useState(initialPolicy);

  const policies = [
    { id: 'privacy', label: 'Privacy Policy (DPDP Act)', icon: ShieldCheck },
    { id: 'terms', label: 'Terms & Conditions', icon: FileText },
    { id: 'shipping', label: 'Shipping Policy', icon: Truck },
    { id: 'returns', label: 'Returns & Refunds', icon: RotateCcw },
    { id: 'cookies', label: 'Cookie Policy', icon: Cookie },
    { id: 'grievance', label: 'Grievance Redressal', icon: HelpCircle }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#F8F6F2] rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col z-10 border border-[#E8E4DE] animate-fadeIn">
        
        {/* Header */}
        <div className="p-6 border-b border-[#E8E4DE] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShieldCheck size={20} className="text-[#171717]" />
            <h2 className="text-sm font-bold tracking-wider uppercase text-[#171717]">
              NEXORA Legal &amp; Compliance Center
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#77736D] hover:text-[#171717]">
            <X size={20} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-[#F0EEEA] border-b border-[#E8E4DE] overflow-x-auto no-scrollbar px-4 py-2 gap-2">
          {policies.map((p) => {
            const Icon = p.icon;
            const active = policyType === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setPolicyType(p.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-colors ${
                  active ? 'bg-[#171717] text-white shadow-xs' : 'bg-white text-[#77736D] hover:text-[#171717]'
                }`}
              >
                <Icon size={14} />
                <span>{p.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 text-xs text-[#77736D] leading-relaxed space-y-4 bg-white">
          {policyType === 'privacy' && (
            <>
              <h3 className="text-sm font-bold text-[#171717] uppercase tracking-wider mb-2">
                Privacy Policy (Aligned with Digital Personal Data Protection Act, 2023)
              </h3>
              <p className="font-mono text-[11px] text-[#A39E93]">Last updated: October 2026 &bull; Effective Date: Immediate</p>
              
              <p>
                NEXORA Apparel Private Limited (&quot;NEXORA&quot;, &quot;we&quot;, &quot;our&quot;) is committed to protecting your personal data in accordance with the Digital Personal Data Protection Act, 2023 (DPDP Act) and applicable Indian laws.
              </p>

              <h4 className="font-bold text-[#171717] pt-2">1. Information We Collect</h4>
              <p>
                We collect only information reasonably necessary for processing your apparel orders and providing customer support: Name, delivery address, phone number, email address, order items, and payment status.
              </p>

              <h4 className="font-bold text-[#171717] pt-2">2. Purpose of Processing</h4>
              <p>
                Your personal data is processed solely for fulfilling orders, managing shipping and logistics, customer support, and complying with statutory tax and accounting obligations.
              </p>

              <h4 className="font-bold text-[#171717] pt-2">3. User Rights &amp; Grievance Redressal</h4>
              <p>
                You have the right to access your personal data, request correction of inaccurate records, or withdraw consent for marketing communications. Contact our Grievance Officer at grievance@nexora.in.
              </p>
            </>
          )}

          {policyType === 'terms' && (
            <>
              <h3 className="text-sm font-bold text-[#171717] uppercase tracking-wider mb-2">Terms and Conditions</h3>
              <p className="font-mono text-[11px] text-[#A39E93]">Last updated: October 2026</p>
              <p>
                Welcome to NEXORA. By accessing our website and purchasing our men&apos;s apparel collections, you agree to abide by these terms and conditions. All prices are listed in Indian Rupees (₹) and include applicable taxes unless stated otherwise.
              </p>
              <p>
                We reserve the right to refuse service, terminate accounts, or cancel orders at our discretion if fraudulent activity or violation of terms is detected.
              </p>
            </>
          )}

          {policyType === 'shipping' && (
            <>
              <h3 className="text-sm font-bold text-[#171717] uppercase tracking-wider mb-2">Shipping and Delivery Policy</h3>
              <p className="font-mono text-[11px] text-[#A39E93]">Last updated: October 2026</p>
              <p>
                NEXORA ships across all major pin codes in India through secure express courier partners.
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Order Processing: Dispatched within 24–48 business hours.</li>
                <li>Delivery Timelines: 3–5 business days for metro cities; 5–7 business days for other locations.</li>
                <li>Shipping Charges: FREE standard shipping on all orders above ₹3,000. Orders below ₹3,000 carry a flat ₹150 delivery charge.</li>
              </ul>
            </>
          )}

          {policyType === 'returns' && (
            <>
              <h3 className="text-sm font-bold text-[#171717] uppercase tracking-wider mb-2">Return, Exchange, and Refund Policy</h3>
              <p className="font-mono text-[11px] text-[#A39E93]">Last updated: October 2026</p>
              <p>
                We offer a hassle-free 14-day return and exchange policy from the date of delivery.
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Products must be unwashed, unworn, and in their original packaging with all tags intact.</li>
                <li>Reverse pickup is arranged free of charge for eligible pin codes.</li>
                <li>Refunds are processed to your original payment method or bank account within 5–7 business days of quality inspection.</li>
              </ul>
            </>
          )}

          {policyType === 'cookies' && (
            <>
              <h3 className="text-sm font-bold text-[#171717] uppercase tracking-wider mb-2">Cookie Policy</h3>
              <p className="font-mono text-[11px] text-[#A39E93]">Last updated: October 2026</p>
              <p>
                NEXORA uses strictly necessary session cookies and local storage tokens to maintain your shopping cart state and secure authentication. We do not utilize intrusive tracking or advertising cookies.
              </p>
            </>
          )}

          {policyType === 'grievance' && (
            <>
              <h3 className="text-sm font-bold text-[#171717] uppercase tracking-wider mb-2">Contact &amp; Grievance Redressal</h3>
              <p className="font-mono text-[11px] text-[#A39E93]">Last updated: October 2026</p>
              <p>
                In accordance with the Information Technology Act, 2000 and the DPDP Act, 2023, the contact details of our Grievance Officer are provided below:
              </p>
              <div className="bg-[#F0EEEA] p-4 rounded text-[#171717] space-y-1">
                <p className="font-bold">Grievance &amp; Privacy Officer: Mr. Vikram Malhotra</p>
                <p>Email: grievance@nexora.in</p>
                <p>Phone: +91 22 4567 8900</p>
                <p>Address: NEXORA Studio, High Street Phoenix, Lower Parel, Mumbai 400013</p>
              </div>
            </>
          )}
        </div>

      </div>
    </div>
  );
};
