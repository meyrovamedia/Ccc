import React, { useState } from 'react';
import { Product } from '../data/products';
import { X, Heart, Star, ShoppingBag, Check } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, color: string, qty: number) => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  isWishlisted,
  onToggleWishlist
}) => {
  const [activeImage, setActiveImage] = useState<string>(product?.image || '');
  const [activeMedia, setActiveMedia] = useState<'image' | 'video'>('image');
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0] || 'M');
  const [selectedColor, setSelectedColor] = useState(product?.colors?.[0] || '#171717');
  const [quantity, setQuantity] = useState(1);
  const [addedAnimation, setAddedAnimation] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#F8F6F2] rounded-xl shadow-2xl max-w-4xl w-full overflow-hidden flex flex-col md:flex-row z-10 border border-[#E8E4DE] animate-fadeIn max-h-[90vh]">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-white/80 hover:bg-white flex items-center justify-center text-[#171717] transition-colors shadow-sm"
        >
          <X size={18} />
        </button>

        {/* Left: Product Image / Gallery & Video */}
        <div className="md:w-1/2 bg-[#E7E4DF] relative min-h-[300px] md:min-h-[480px] flex flex-col justify-between">
          {product.badge && (
            <span className="absolute top-4 left-4 z-10 bg-[#171717] text-white text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded shadow-sm">
              {product.badge}
            </span>
          )}
          <div className="flex-1 relative overflow-hidden flex items-center justify-center min-h-[320px]">
            {activeMedia === 'video' && product.video ? (
              <video src={product.video} controls autoPlay className="w-full h-full object-cover" />
            ) : (
              <img
                src={activeImage || product.image}
                alt={product.name}
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
            )}
          </div>

          {/* Gallery Thumbnails & Video toggle */}
          {((product.images && product.images.length > 0) || product.video) && (
            <div className="p-3 bg-white/90 backdrop-blur-md flex items-center gap-2 overflow-x-auto border-t border-[#E8E4DE]">
              <button
                onClick={() => { setActiveImage(product.image); setActiveMedia('image'); }}
                className={`w-12 h-12 rounded overflow-hidden shrink-0 border-2 transition-all ${activeMedia === 'image' && (activeImage === product.image || !activeImage) ? 'border-[#171717] scale-105' : 'border-transparent opacity-70'}`}
              >
                <img src={product.image} alt="thumb" className="w-full h-full object-cover" />
              </button>
              {product.images?.map((imgUrl, idx) => (
                <button
                  key={idx}
                  onClick={() => { setActiveImage(imgUrl); setActiveMedia('image'); }}
                  className={`w-12 h-12 rounded overflow-hidden shrink-0 border-2 transition-all ${activeMedia === 'image' && activeImage === imgUrl ? 'border-[#171717] scale-105' : 'border-transparent opacity-70'}`}
                >
                  <img src={imgUrl} alt={`thumb-${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
              {product.video && (
                <button
                  onClick={() => setActiveMedia('video')}
                  className={`w-12 h-12 rounded bg-[#171717] text-white text-[10px] font-mono flex items-center justify-center shrink-0 border-2 transition-all ${activeMedia === 'video' ? 'border-[#171717] scale-105' : 'border-transparent opacity-70'}`}
                  title="Play product video"
                >
                  ▶ Video
                </button>
              )}
            </div>
          )}
        </div>

        {/* Right: Product Info & Actions */}
        <div className="md:w-1/2 p-6 sm:p-8 overflow-y-auto flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-mono tracking-widest text-[#77736D] uppercase">
                NEXORA &bull; {product.category}
              </span>
              <div className="flex items-center gap-1 text-xs text-[#171717] font-mono">
                <Star size={13} className="fill-current text-[#171717]" />
                <span>{product.rating}</span>
                <span className="text-[#77736D]">({product.reviewsCount} reviews)</span>
              </div>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-[#171717] mb-2">
              {product.name}
            </h2>

            <div className="text-lg font-mono font-semibold text-[#171717] mb-4">
              ₹{product.price.toLocaleString()}
            </div>

            <p className="text-xs sm:text-sm text-[#77736D] leading-relaxed mb-6">
              {product.description}
            </p>

            {/* Color Selection */}
            <div className="mb-5">
              <span className="text-xs font-bold uppercase tracking-wider text-[#171717] block mb-2">
                Color: <span className="font-normal text-[#77736D]">{selectedColor}</span>
              </span>
              <div className="flex items-center gap-2.5">
                {product.colors.map((c) => (
                  <button
                    key={c}
                    onClick={() => setSelectedColor(c)}
                    className={`w-7 h-7 rounded-full border transition-transform ${
                      selectedColor === c ? 'ring-2 ring-offset-2 ring-[#171717] scale-110' : 'border-[#E8E4DE]'
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#171717]">
                  Size
                </span>
                <button
                  onClick={() => alert('Size Guide: Standard contemporary menswear sizing. True to size fit.')}
                  className="text-[11px] text-[#77736D] underline hover:text-[#171717]"
                >
                  Size Guide
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`min-w-[42px] h-10 px-3 rounded text-xs font-medium border transition-colors ${
                      selectedSize === sz
                        ? 'bg-[#171717] text-white border-[#171717]'
                        : 'bg-white text-[#171717] border-[#E8E4DE] hover:border-[#171717]'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Actions */}
          <div className="pt-4 border-t border-[#E8E4DE] flex items-center gap-4">
            {/* Quantity */}
            <div className="flex items-center border border-[#E8E4DE] rounded bg-white">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-3 py-2 text-xs text-[#77736D] hover:text-[#171717]"
              >
                -
              </button>
              <span className="px-3 py-2 text-xs font-mono font-medium">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="px-3 py-2 text-xs text-[#77736D] hover:text-[#171717]"
              >
                +
              </button>
            </div>

            {/* Add to Bag Button */}
            <button
              onClick={handleAdd}
              className={`flex-1 py-3 px-6 rounded text-xs font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-sm ${
                addedAnimation ? 'bg-emerald-700 text-white' : 'bg-[#171717] text-white hover:bg-[#333333]'
              }`}
            >
              {addedAnimation ? (
                <>
                  <Check size={16} /> Added to Bag
                </>
              ) : (
                <>
                  <ShoppingBag size={16} /> Add to Bag &bull; ₹{(product.price * quantity).toLocaleString()}
                </>
              )}
            </button>

            {/* Wishlist Button */}
            <button
              onClick={(e) => onToggleWishlist(product, e)}
              className="p-3 rounded border border-[#E8E4DE] bg-white hover:border-[#171717] transition-colors"
              title="Wishlist"
            >
              <Heart
                size={18}
                className={isWishlisted ? 'fill-[#171717] text-[#171717]' : 'text-[#171717]'}
                strokeWidth={1.5}
              />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
