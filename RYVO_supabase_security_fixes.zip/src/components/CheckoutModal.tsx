import React, { useState } from 'react';
import { CartItem } from './CartDrawer';
import { X, CheckCircle, ShieldCheck, Truck, CreditCard } from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderComplete: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  onOrderComplete
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<'form' | 'success'>('form');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [orderResult, setOrderResult] = useState<{ orderId: string; trackingNumber: string } | null>(null);

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    pincode: '',
    paymentMethod: 'cod'
  });

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const shipping = subtotal >= 3000 ? 0 : 150;
  const total = subtotal + shipping;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.phone || !formData.address) {
      alert('Please fill in all required shipping fields.');
      return;
    }

    setLoading(true);
    setErrorMessage('');

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: formData.fullName,
          customerEmail: formData.email || 'guest@ryvo.in',
          customerPhone: formData.phone,
          address: `${formData.address}, ${formData.city} - ${formData.pincode}`,
          items: items.map(i => ({
            product: i.product,
            quantity: i.quantity,
            size: i.size,
            color: i.color
          })),
          paymentMethod: formData.paymentMethod
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to place order.');
      }

      if (formData.paymentMethod === 'online' && data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
        return;
      }

      setOrderResult({ orderId: data.orderId, trackingNumber: data.trackingNumber });
      setStep('success');
      onOrderComplete();
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred during checkout.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#F8F6F2] rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col z-10 border border-[#E8E4DE] animate-fadeIn">
        
        {/* Header */}
        <div className="p-6 border-b border-[#E8E4DE] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShieldCheck size={20} className="text-[#171717]" />
            <h2 className="text-sm font-bold tracking-wider uppercase text-[#171717]">
              {step === 'form' ? 'NEXORA Secure Checkout' : 'Order Confirmation'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#77736D] hover:text-[#171717]">
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {step === 'form' ? (
            <form onSubmit={handleSubmit} className="flex flex-col gap-6">
              
              {/* Order Summary Box */}
              <div className="bg-white p-4 rounded border border-[#E8E4DE]">
                <div className="text-xs font-bold uppercase tracking-wider text-[#171717] mb-2">
                  Order Summary ({items.reduce((a, c) => a + c.quantity, 0)} items)
                </div>
                <div className="flex flex-col gap-2 max-h-36 overflow-y-auto pr-1">
                  {items.map((item) => (
                    <div key={item.cartId} className="flex items-center justify-between text-xs">
                      <span className="text-[#77736D] truncate max-w-[240px]">
                        {item.product.name} (x{item.quantity})
                      </span>
                      <span className="font-mono font-medium text-[#171717]">
                        ₹{(item.product.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="pt-3 mt-3 border-t border-[#E8E4DE] flex items-center justify-between text-xs font-bold text-[#171717]">
                  <span>Total Amount (incl. shipping)</span>
                  <span className="font-mono text-sm">₹{total.toLocaleString()}</span>
                </div>
              </div>

              {/* Shipping Details */}
              <div className="flex flex-col gap-3">
                <div className="text-xs font-bold uppercase tracking-wider text-[#171717]">
                  Shipping Address
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="Aarav Sharma"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2 focus:outline-none focus:border-[#171717]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2 focus:outline-none focus:border-[#171717]"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-[#77736D] block mb-1">Street Address *</label>
                  <input
                    type="text"
                    required
                    placeholder="House No, Apartment, Street name"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2 focus:outline-none focus:border-[#171717]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">City *</label>
                    <input
                      type="text"
                      required
                      placeholder="Mumbai"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2 focus:outline-none focus:border-[#171717]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#77736D] block mb-1">Postal Code *</label>
                    <input
                      type="text"
                      required
                      placeholder="400001"
                      value={formData.pincode}
                      onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                      className="w-full bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2 focus:outline-none focus:border-[#171717]"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Method */}
              <div className="flex flex-col gap-3">
                <div className="text-xs font-bold uppercase tracking-wider text-[#171717]">
                  Payment Method
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <label className={`p-3 rounded border cursor-pointer flex items-center gap-3 bg-white ${formData.paymentMethod === 'cod' ? 'border-[#171717] ring-1 ring-[#171717]' : 'border-[#E8E4DE]'}`}>
                    <input
                      type="radio"
                      name="payment"
                      checked={formData.paymentMethod === 'cod'}
                      onChange={() => setFormData({ ...formData, paymentMethod: 'cod' })}
                      className="accent-[#171717]"
                    />
                    <div>
                      <span className="text-xs font-semibold block">Cash on Delivery</span>
                      <span className="text-[10px] text-[#77736D]">Pay when you receive</span>
                    </div>
                  </label>

                  <label className={`p-3 rounded border cursor-pointer flex items-center gap-3 bg-white ${formData.paymentMethod === 'online' ? 'border-[#171717] ring-1 ring-[#171717]' : 'border-[#E8E4DE]'}`}>
                    <input
                      type="radio"
                      name="payment"
                      checked={formData.paymentMethod === 'online'}
                      onChange={() => setFormData({ ...formData, paymentMethod: 'online' })}
                      className="accent-[#171717]"
                    />
                    <div>
                      <span className="text-xs font-semibold block">Online / UPI / Card</span>
                      <span className="text-[10px] text-[#77736D]">Secure gateway</span>
                    </div>
                  </label>
                </div>
              </div>

              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
                  {errorMessage}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#171717] text-white text-xs font-bold tracking-wider uppercase py-3.5 rounded hover:bg-[#333333] transition-colors shadow-sm disabled:opacity-50"
              >
                {loading ? 'Processing Order & Payment...' : `Place Order • ₹${total.toLocaleString()}`}
              </button>
            </form>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <CheckCircle size={56} className="text-emerald-700 mb-4 stroke-[1.5]" />
              <h3 className="text-base font-bold text-[#171717] mb-1">Order Placed Successfully!</h3>
              <p className="text-xs font-mono text-[#77736D] mb-2">
                Order ID: <b>{orderResult?.orderId || 'ORD-98214'}</b> &bull; Tracking: <b>{orderResult?.trackingNumber || 'TRK-IN-889123'}</b>
              </p>
              <p className="text-xs text-[#77736D] max-w-sm mb-8 leading-relaxed">
                Thank you for shopping with RYVO. Your order has been securely saved in our database and is being prepared for express dispatch.
              </p>
              <button
                onClick={onClose}
                className="bg-[#171717] text-white text-xs font-medium px-8 py-3 rounded hover:bg-[#333333] transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
