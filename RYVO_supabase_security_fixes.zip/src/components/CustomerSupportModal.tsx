import React, { useState } from 'react';
import { X, Headphones, Mail, Phone, MapPin, CheckCircle } from 'lucide-react';

interface CustomerSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CustomerSupportModal: React.FC<CustomerSupportModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', orderId: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#F8F6F2] rounded-xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-hidden flex flex-col z-10 border border-[#E8E4DE] animate-fadeIn">
        
        {/* Header */}
        <div className="p-6 border-b border-[#E8E4DE] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <Headphones size={20} className="text-[#171717]" />
            <h2 className="text-sm font-bold tracking-wider uppercase text-[#171717]">
              Customer Support &amp; Grievance Redressal
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#77736D] hover:text-[#171717]">
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
          {/* Verified Contact Details */}
          <div className="bg-white p-5 rounded border border-[#E8E4DE] flex flex-col gap-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#171717]">Verified Business Contact</h3>
            <div className="flex items-center gap-3 text-xs text-[#77736D]">
              <Mail size={15} className="shrink-0 text-[#171717]" />
              <span>support@nexora.in (Response within 24 hours)</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-[#77736D]">
              <Phone size={15} className="shrink-0 text-[#171717]" />
              <span className="font-mono">+91 22 4567 8900 (Mon-Sat, 10:00 AM - 6:00 PM IST)</span>
            </div>
            <div className="flex items-start gap-3 text-xs text-[#77736D]">
              <MapPin size={15} className="shrink-0 text-[#171717] mt-0.5" />
              <span>NEXORA Studio, 4th Floor, High Street Phoenix, Lower Parel, Mumbai, Maharashtra 400013</span>
            </div>
          </div>

          {/* Grievance Officer */}
          <div className="bg-[#F0EEEA] p-4 rounded border border-[#E8E4DE] text-xs">
            <span className="font-bold text-[#171717] block mb-1">Grievance &amp; Privacy Officer (Under DPDP Act 2023)</span>
            <span className="text-[#77736D] block">Mr. Vikram Malhotra &bull; grievance@nexora.in</span>
          </div>

          {/* Support Form */}
          {submitted ? (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded text-xs flex items-center gap-3">
              <CheckCircle size={20} className="shrink-0" />
              <div>
                <span className="font-bold block">Support Request Received</span>
                <span>Ticket #NEX-{Math.floor(10000 + Math.random() * 90000)} generated. Our team will contact you shortly.</span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-3 bg-white p-5 rounded border border-[#E8E4DE]">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#171717] mb-1">Submit Support Inquiry</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-[#77736D] block mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Aarav Sharma"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#77736D] block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="aarav@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                  />
                </div>
              </div>
              <div>
                <label className="text-[11px] text-[#77736D] block mb-1">Order ID (optional)</label>
                <input
                  type="text"
                  placeholder="ORD-98214"
                  value={formData.orderId}
                  onChange={(e) => setFormData({ ...formData, orderId: e.target.value })}
                  className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2 font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] text-[#77736D] block mb-1">Message / Inquiry</label>
                <textarea
                  required
                  rows={3}
                  placeholder="How can we assist you with your order or return?"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full bg-[#F8F6F2] border border-[#E8E4DE] rounded text-xs px-3 py-2"
                />
              </div>
              <button
                type="submit"
                className="mt-2 bg-[#171717] text-white text-xs font-bold uppercase tracking-wider py-2.5 rounded hover:bg-[#333333] transition-colors"
              >
                Send Support Ticket
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
