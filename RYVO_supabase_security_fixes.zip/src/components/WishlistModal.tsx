import React from 'react';
import { Product } from '../data/products';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistProducts: Product[];
  onRemoveWishlist: (product: Product) => void;
  onAddToCart: (product: Product, size: string, color: string, qty: number) => void;
  onSelectProduct: (product: Product) => void;
}

export const WishlistModal: React.FC<WishlistModalProps> = ({
  isOpen,
  onClose,
  wishlistProducts,
  onRemoveWishlist,
  onAddToCart,
  onSelectProduct
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="fixed inset-0 bg-black/40 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#F8F6F2] rounded-xl shadow-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col z-10 border border-[#E8E4DE] animate-fadeIn">
        
        {/* Header */}
        <div className="p-6 border-b border-[#E8E4DE] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <Heart size={20} className="fill-[#171717] text-[#171717]" />
            <h2 className="text-sm font-bold tracking-wider uppercase text-[#171717]">
              My Wishlist ({wishlistProducts.length})
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#77736D] hover:text-[#171717]">
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
          {wishlistProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Heart size={48} className="text-[#77736D] mb-3 stroke-[1.2]" />
              <h3 className="text-sm font-bold text-[#171717] mb-1">Your wishlist is empty</h3>
              <p className="text-xs text-[#77736D] max-w-xs mb-6">
                Tap the heart icon on any product card to save your favorite items here.
              </p>
              <button
                onClick={onClose}
                className="bg-[#171717] text-white text-xs font-medium px-6 py-2.5 rounded hover:bg-[#333333] transition-colors"
              >
                Browse Collection
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {wishlistProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded border border-[#E8E4DE] p-4 flex flex-col justify-between group"
                >
                  <div>
                    <div className="relative aspect-[4/3] bg-[#E7E4DF] rounded overflow-hidden mb-3">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover cursor-pointer group-hover:scale-105 transition-transform"
                        onClick={() => {
                          onSelectProduct(product);
                          onClose();
                        }}
                        referrerPolicy="no-referrer"
                      />
                      <button
                        onClick={() => onRemoveWishlist(product)}
                        className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/90 flex items-center justify-center text-[#171717] hover:bg-white shadow-sm"
                        title="Remove from wishlist"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>

                    <h4
                      className="text-xs font-semibold text-[#171717] cursor-pointer hover:underline truncate mb-1"
                      onClick={() => {
                        onSelectProduct(product);
                        onClose();
                      }}
                    >
                      {product.name}
                    </h4>
                    <div className="text-xs font-mono font-medium text-[#171717] mb-3">
                      ₹{product.price.toLocaleString()}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onAddToCart(product, product.sizes[0] || 'M', product.colors[0] || '#171717', 1);
                      onRemoveWishlist(product);
                    }}
                    className="w-full bg-[#171717] text-white text-xs font-medium py-2 rounded hover:bg-[#333333] transition-colors flex items-center justify-center gap-1.5"
                  >
                    <ShoppingBag size={14} /> Move to Bag
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
