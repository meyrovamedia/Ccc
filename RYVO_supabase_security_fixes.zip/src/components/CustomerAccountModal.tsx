import React, { useState } from 'react';
import { X, User, Package, Shield, Download, Trash2, CheckCircle } from 'lucide-react';

interface CustomerAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CustomerAccountModal: React.FC<CustomerAccountModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [tab, setTab] = useState<'signin' | 'orders' | 'privacy'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [dataRequestSent, setDataRequestSent] = useState(false);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setIsLoggedIn(true);
    setTab('orders');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#F8F6F2] rounded-xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-hidden flex flex-col z-10 border border-[#E8E4DE] animate-fadeIn">
        
        {/* Header */}
        <div className="p-6 border-b border-[#E8E4DE] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <User size={20} className="text-[#171717]" />
            <h2 className="text-sm font-bold tracking-wider uppercase text-[#171717]">
              {isLoggedIn ? 'Customer Account & Privacy Center' : 'Sign In to NEXORA'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#77736D] hover:text-[#171717]">
            <X size={20} />
          </button>
        </div>

        {/* Tabs if logged in */}
        {isLoggedIn && (
          <div className="flex bg-[#F0EEEA] border-b border-[#E8E4DE] text-xs font-medium">
            <button
              onClick={() => setTab('orders')}
              className={`flex-1 py-3 text-center transition-colors ${tab === 'orders' ? 'bg-white font-bold text-[#171717] border-b-2 border-[#171717]' : 'text-[#77736D]'}`}
            >
              Order History
            </button>
            <button
              onClick={() => setTab('privacy')}
              className={`flex-1 py-3 text-center transition-colors ${tab === 'privacy' ? 'bg-white font-bold text-[#171717] border-b-2 border-[#171717]' : 'text-[#77736D]'}`}
            >
              DPDP Data Rights & Privacy
            </button>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {!isLoggedIn ? (
            <form onSubmit={handleSignIn} className="flex flex-col gap-4">
              <p className="text-xs text-[#77736D]">
                Sign in securely to view your order history, track deliveries, and manage your personal data preferences.
              </p>
              <div>
                <label className="text-[11px] text-[#77736D] block mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="aarav.sharma@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2.5"
                />
              </div>
              <div>
                <label className="text-[11px] text-[#77736D] block mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2.5"
                />
              </div>
              <button
                type="submit"
                className="mt-2 w-full bg-[#171717] text-white text-xs font-bold tracking-wider uppercase py-3 rounded hover:bg-[#333333] transition-colors"
              >
                Sign In / Register
              </button>
            </form>
          ) : tab === 'orders' ? (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between bg-white p-4 rounded border border-[#E8E4DE]">
                <div>
                  <span className="text-xs font-bold text-[#171717] block">Welcome back, {email}</span>
                  <span className="text-[11px] text-[#77736D]">Customer ID: CUST-88192</span>
                </div>
                <button
                  onClick={() => setIsLoggedIn(false)}
                  className="text-xs text-red-600 underline"
                >
                  Sign Out
                </button>
              </div>

              <h3 className="text-xs font-bold uppercase tracking-wider text-[#171717] mt-2">Your Orders</h3>
              <div className="bg-white p-4 rounded border border-[#E8E4DE] flex flex-col gap-3">
                <div className="flex items-center justify-between text-xs border-b border-[#E8E4DE] pb-2">
                  <span className="font-mono font-semibold">ORD-98214</span>
                  <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px]">Delivered</span>
                </div>
                <div className="text-xs text-[#77736D]">
                  Oversized Utility Overshirt (x1) &bull; ₹2,790
                </div>
                <div className="text-[11px] text-[#77736D] font-mono">
                  Tracking: TRK-IN-889123 &bull; Delivered via Express Courier
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="bg-white p-5 rounded border border-[#E8E4DE]">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#171717] mb-2">
                  <Shield size={16} /> Digital Personal Data Protection Act (DPDP) 2023 Rights
                </div>
                <p className="text-xs text-[#77736D] leading-relaxed mb-4">
                  As a registered customer, you have the statutory right under the DPDP Act to request access to your personal data, request correction of inaccurate records, or withdraw consent for marketing.
                </p>

                {dataRequestSent ? (
                  <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded text-xs flex items-center gap-2">
                    <CheckCircle size={16} /> Your data request has been logged and sent to the Grievance Officer. We will process it within 72 hours.
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => setDataRequestSent(true)}
                      className="w-full bg-white border border-[#E8E4DE] text-[#171717] text-xs font-medium py-2.5 rounded hover:bg-[#F0EEEA] transition-colors flex items-center justify-center gap-2"
                    >
                      <Download size={15} /> Request Data Export &amp; Access Summary
                    </button>
                    <button
                      onClick={() => alert('Consent withdrawal registered. Marketing communications have been disabled.')}
                      className="w-full bg-white border border-[#E8E4DE] text-[#171717] text-xs font-medium py-2.5 rounded hover:bg-[#F0EEEA] transition-colors"
                    >
                      Withdraw Marketing Consent
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
