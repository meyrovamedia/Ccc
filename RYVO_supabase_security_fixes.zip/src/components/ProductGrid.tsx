import React from 'react';
import { Product } from '../data/products';
import { ProductCard } from './ProductCard';
import { PackageOpen } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  wishlistIds: string[];
  onToggleWishlist: (product: Product, e: React.MouseEvent) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  wishlistIds,
  onToggleWishlist,
  onSelectProduct
}) => {
  if (products.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 bg-white/50 rounded-lg border border-[#E8E4DE] text-center">
        <PackageOpen size={40} className="text-[#77736D] mb-3 stroke-[1.5]" />
        <h3 className="text-sm font-bold text-[#171717] mb-1">No products found</h3>
        <p className="text-xs text-[#77736D] max-w-xs">
          Try adjusting your search query, price range, or filter criteria to find what you are looking for.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          isWishlisted={wishlistIds.includes(product.id)}
          onToggleWishlist={onToggleWishlist}
          onSelectProduct={onSelectProduct}
        />
      ))}
    </div>
  );
};
