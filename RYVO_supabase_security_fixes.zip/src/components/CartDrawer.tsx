import React from 'react';
import { Product } from '../data/products';
import { X, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';

export interface CartItem {
  cartId: string;
  product: Product;
  size: string;
  color: string;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartId: string, delta: number) => void;
  onRemoveItem: (cartId: string) => void;
  onProceedCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedCheckout
}) => {
  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const freeDeliveryThreshold = 3000;
  const progress = Math.min(100, (subtotal / freeDeliveryThreshold) * 100);

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="fixed inset-0 bg-black/40 backdrop-blur-xs" onClick={onClose} />
      <div className="relative w-full max-w-md bg-[#F8F6F2] h-full shadow-2xl flex flex-col z-10 animate-slideLeft">
        
        {/* Header */}
        <div className="p-6 border-b border-[#E8E4DE] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag size={20} className="text-[#171717]" />
            <h2 className="text-sm font-bold tracking-wider uppercase text-[#171717]">
              Shopping Bag ({items.reduce((a, c) => a + c.quantity, 0)})
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#77736D] hover:text-[#171717]">
            <X size={20} />
          </button>
        </div>

        {/* Free Delivery Banner */}
        <div className="bg-[#E8E0D6] px-6 py-3 border-b border-[#E8E4DE]">
          <div className="flex items-center justify-between text-xs font-medium text-[#171717] mb-1.5">
            <span>
              {subtotal >= freeDeliveryThreshold
                ? '🎉 You unlocked Free Express Delivery!'
                : `Add ₹${(freeDeliveryThreshold - subtotal).toLocaleString()} more for Free Delivery`}
            </span>
            <span className="font-mono">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-[#E8E4DE] h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-[#171717] h-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <ShoppingBag size={48} className="text-[#77736D] mb-3 stroke-[1.2]" />
              <h3 className="text-sm font-bold text-[#171717] mb-1">Your shopping bag is empty</h3>
              <p className="text-xs text-[#77736D] max-w-xs mb-6">
                Explore our latest collection and add your favorite NEXORA essentials.
              </p>
              <button
                onClick={onClose}
                className="bg-[#171717] text-white text-xs font-medium px-6 py-2.5 rounded hover:bg-[#333333] transition-colors"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.cartId}
                className="flex gap-4 p-4 bg-white rounded border border-[#E8E4DE] relative group"
              >
                <div className="w-20 h-24 bg-[#E7E4DF] rounded overflow-hidden shrink-0">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between">
                      <h4 className="text-xs font-semibold text-[#171717] pr-6">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.cartId)}
                        className="text-[#77736D] hover:text-[#171717] transition-colors"
                        title="Remove item"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-[#77736D]">
                      <span>Size: {item.size}</span>
                      <span>&bull;</span>
                      <span className="flex items-center gap-1">
                        Color: <span className="w-2.5 h-2.5 rounded-full inline-block border border-[#E8E4DE]" style={{ backgroundColor: item.color }} />
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-[#E8E4DE] rounded">
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, -1)}
                        className="px-2 py-1 text-xs text-[#77736D] hover:text-[#171717]"
                      >
                        -
                      </button>
                      <span className="px-2 py-1 text-xs font-mono font-medium">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, 1)}
                        className="px-2 py-1 text-xs text-[#77736D] hover:text-[#171717]"
                      >
                        +
                      </button>
                    </div>
                    <span className="text-xs font-mono font-semibold text-[#171717]">
                      ₹{(item.product.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer / Checkout */}
        {items.length > 0 && (
          <div className="p-6 bg-white border-t border-[#E8E4DE] flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs text-[#77736D]">
              <span>Subtotal</span>
              <span className="font-mono font-semibold text-[#171717] text-sm">
                ₹{subtotal.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs text-[#77736D]">
              <span>Shipping</span>
              <span className="font-mono text-[#171717]">
                {subtotal >= freeDeliveryThreshold ? 'FREE' : '₹150'}
              </span>
            </div>
            <div className="pt-2 border-t border-[#E8E4DE] flex items-center justify-between text-sm font-bold text-[#171717]">
              <span>Total</span>
              <span className="font-mono text-base">
                ₹{(subtotal + (subtotal >= freeDeliveryThreshold ? 0 : 150)).toLocaleString()}
              </span>
            </div>

            <button
              onClick={onProceedCheckout}
              className="w-full mt-2 bg-[#171717] text-white text-xs font-bold tracking-wider uppercase py-3.5 rounded hover:bg-[#333333] transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight size={16} />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
