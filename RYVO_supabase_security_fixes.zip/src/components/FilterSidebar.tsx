import React from 'react';
import { CATEGORIES, SIZES, COLORS } from '../data/products';
import { SlidersHorizontal, X } from 'lucide-react';

interface FilterSidebarProps {
  selectedCategories: string[];
  onToggleCategory: (cat: string) => void;
  selectedSizes: string[];
  onToggleSize: (size: string) => void;
  selectedColors: string[];
  onToggleColor: (color: string) => void;
  priceRange: number;
  onPriceChange: (price: number) => void;
  onClearAll: () => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  selectedCategories,
  onToggleCategory,
  selectedSizes,
  onToggleSize,
  selectedColors,
  onToggleColor,
  priceRange,
  onPriceChange,
  onClearAll,
  isOpenMobile,
  onCloseMobile
}) => {
  const categoryCounts: Record<string, number> = {
    'T-Shirts': 12,
    'Shirts': 18,
    'Overshirts': 14,
    'Trousers': 10,
    'Jeans': 8,
    'Jackets': 6
  };

  const sizeCounts: Record<string, number> = {
    'XS': 32,
    'S': 68,
    'M': 96,
    'L': 88,
    'XL': 42,
    'XXL': 18
  };

  const content = (
    <div className="w-full lg:w-64 bg-[#F8F6F2] lg:bg-transparent pr-0 lg:pr-6 flex flex-col gap-6 text-[#171717]">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#E8E4DE]">
        <div className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase">
          <SlidersHorizontal size={14} />
          <span>FILTERS</span>
        </div>
        <button
          onClick={onClearAll}
          className="text-xs text-[#77736D] hover:text-[#171717] underline transition-colors"
        >
          Clear All
        </button>
      </div>

      {/* Category Filter */}
      <div className="pb-4 border-b border-[#E8E4DE]">
        <div className="text-xs font-bold uppercase tracking-wider mb-3 text-[#171717]">
          Category
        </div>
        <div className="flex flex-col gap-2.5">
          {Object.entries(categoryCounts).map(([cat, count]) => {
            const checked = selectedCategories.includes(cat);
            return (
              <label key={cat} className="flex items-center justify-between text-xs cursor-pointer group">
                <div className="flex items-center gap-2.5">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => onToggleCategory(cat)}
                    className="rounded border-[#E8E4DE] text-[#171717] focus:ring-0 w-3.5 h-3.5 accent-[#171717]"
                  />
                  <span className={`group-hover:text-[#171717] ${checked ? 'font-semibold text-[#171717]' : 'text-[#77736D]'}`}>
                    {cat}
                  </span>
                </div>
                <span className="text-[11px] text-[#77736D] font-mono">{count}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* Size Filter */}
      <div className="pb-4 border-b border-[#E8E4DE]">
        <div className="text-xs font-bold uppercase tracking-wider mb-3 text-[#171717]">
          Size
        </div>
        <div className="flex flex-col gap-2.5">
          {Object.entries(sizeCounts).map(([size, count]) => {
            const checked = selectedSizes.includes(size);
            return (
              <label key={size} className="flex items-center justify-between text-xs cursor-pointer group">
                <div className="flex items-center gap-2.5">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => onToggleSize(size)}
                    className="rounded border-[#E8E4DE] text-[#171717] focus:ring-0 w-3.5 h-3.5 accent-[#171717]"
                  />
                  <span className={`group-hover:text-[#171717] ${checked ? 'font-semibold text-[#171717]' : 'text-[#77736D]'}`}>
                    {size}
                  </span>
                </div>
                <span className="text-[11px] text-[#77736D] font-mono">{count}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* Color Filter */}
      <div className="pb-4 border-b border-[#E8E4DE]">
        <div className="text-xs font-bold uppercase tracking-wider mb-3 text-[#171717]">
          Color
        </div>
        <div className="flex flex-wrap gap-2.5">
          {COLORS.map((col) => {
            const selected = selectedColors.includes(col.name);
            return (
              <button
                key={col.name}
                onClick={() => onToggleColor(col.name)}
                title={col.name}
                className={`w-6 h-6 rounded-full border transition-transform ${
                  selected ? 'ring-2 ring-offset-2 ring-[#171717] scale-110' : 'border-[#E8E4DE] hover:scale-105'
                }`}
                style={{ backgroundColor: col.hex }}
              />
            );
          })}
        </div>
      </div>

      {/* Price Range Filter */}
      <div>
        <div className="text-xs font-bold uppercase tracking-wider mb-3 text-[#171717]">
          Price
        </div>
        <div className="flex flex-col gap-2">
          <input
            type="range"
            min={1000}
            max={5000}
            step={100}
            value={priceRange}
            onChange={(e) => onPriceChange(Number(e.target.value))}
            className="w-full accent-[#171717] cursor-pointer"
          />
          <div className="flex items-center justify-between text-xs font-mono text-[#77736D]">
            <span>₹1,000</span>
            <span className="font-semibold text-[#171717]">₹{priceRange.toLocaleString()}</span>
            <span>₹5,000+</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block shrink-0">
        {content}
      </aside>

      {/* Mobile Drawer */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs" onClick={onCloseMobile} />
          <div className="relative w-80 max-w-full bg-[#F8F6F2] h-full shadow-2xl p-6 overflow-y-auto flex flex-col z-10 animate-slideRight">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-[#E8E4DE]">
              <span className="text-sm font-bold uppercase tracking-wider">Filters</span>
              <button onClick={onCloseMobile} className="p-1 text-[#77736D] hover:text-[#171717]">
                <X size={20} />
              </button>
            </div>
            {content}
          </div>
        </div>
      )}
    </>
  );
};
