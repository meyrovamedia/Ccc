import React from 'react';
import { Package, ShieldCheck, RotateCcw, Headphones } from 'lucide-react';

export const BenefitsStrip: React.FC = () => {
  const benefits = [
    {
      icon: Package,
      title: 'QUALITY FIRST',
      desc: 'Thoughtfully selected essentials.'
    },
    {
      icon: ShieldCheck,
      title: 'SECURE CHECKOUT',
      desc: 'Protected payment experience.'
    },
    {
      icon: RotateCcw,
      title: 'EASY RETURNS',
      desc: 'See our return policy.'
    },
    {
      icon: Headphones,
      title: 'CUSTOMER SUPPORT',
      desc: "We're here to help."
    }
  ];

  return (
    <div className="px-6 lg:px-12 py-10 bg-[#F8F6F2] border-t border-[#E8E4DE]">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {benefits.map((b, i) => {
          const Icon = b.icon;
          return (
            <div key={i} className="flex items-start gap-4">
              <div className="p-2.5 rounded bg-[#F0EEEA] text-[#171717] shrink-0">
                <Icon size={20} strokeWidth={1.5} />
              </div>
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#171717] mb-0.5">
                  {b.title}
                </h4>
                <p className="text-xs text-[#77736D] leading-relaxed">
                  {b.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
