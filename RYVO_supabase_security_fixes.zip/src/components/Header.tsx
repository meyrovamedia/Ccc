import React, { useState } from 'react';
import { Search, User, Heart, ShoppingBag, Menu, X, Shield, Headphones } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenAccount: () => void;
  onOpenSupport: () => void;
  onOpenAdmin: () => void;
  activeNav: string;
  onSelectNav: (nav: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenAccount,
  onOpenSupport,
  onOpenAdmin,
  activeNav,
  onSelectNav,
  searchQuery,
  onSearchChange
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const navItems = ['Home', 'Shop', 'New Arrivals', 'T-Shirts', 'Shirts', 'Trousers', 'Collections'];

  return (
    <header className="sticky top-0 z-40 bg-[#F8F6F2] border-b border-[#E8E4DE] px-6 lg:px-12 h-[70px] flex items-center justify-between transition-all">
      {/* Left: Logo */}
      <div className="flex items-center gap-2.5 sm:gap-4">
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-1 text-[#171717] hover:text-[#77736D] transition-colors flex items-center justify-center"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        <button
          onClick={() => onSelectNav('Home')}
          className="text-base sm:text-xl md:text-2xl font-bold tracking-[0.15em] sm:tracking-[0.25em] text-[#171717] focus:outline-none whitespace-nowrap leading-none flex items-center"
        >
          RYVO CLOTHES
        </button>
      </div>

      {/* Center: Navigation Links */}
      <nav className="hidden md:flex items-center gap-8 text-[13px] font-medium tracking-wide text-[#171717]">
        {navItems.map((item) => (
          <button
            key={item}
            onClick={() => onSelectNav(item)}
            className={`transition-colors hover:text-[#171717] pb-1 relative ${
              activeNav === item ? 'text-[#171717] font-semibold border-b-2 border-[#171717]' : 'text-[#77736D]'
            }`}
          >
            {item}
          </button>
        ))}
      </nav>

      {/* Right: Icons */}
      <div className="flex items-center gap-4 sm:gap-5 text-[#171717]">
        {/* Admin button */}
        <button
          onClick={onOpenAdmin}
          className="p-1.5 hover:text-[#77736D] transition-colors text-xs font-mono flex items-center gap-1 bg-[#F0EEEA] px-2.5 py-1 rounded"
          title="Admin Control Center"
        >
          <Shield size={14} />
          <span>Admin</span>
        </button>

        {/* Support button */}
        <button
          onClick={onOpenSupport}
          className="p-1.5 hover:text-[#77736D] transition-colors hidden sm:block"
          title="Customer Support"
        >
          <Headphones size={20} strokeWidth={1.5} />
        </button>

        {/* Search Input toggle on desktop / mobile */}
        <div className="relative flex items-center">
          {searchOpen ? (
            <div className="flex items-center bg-white border border-[#E8E4DE] rounded px-2 py-1 shadow-sm">
              <Search size={16} className="text-[#77736D] mr-2 shrink-0" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                autoFocus
                className="text-xs bg-transparent outline-none w-36 sm:w-48 text-[#171717]"
              />
              <button
                onClick={() => setSearchOpen(false)}
                className="text-xs text-[#77736D] hover:text-[#171717] ml-1 px-1"
              >
                ✕
              </button>
            </div>
          ) : (
            <button
              onClick={() => setSearchOpen(true)}
              className="p-1.5 hover:text-[#77736D] transition-colors"
              title="Search"
            >
              <Search size={20} strokeWidth={1.5} />
            </button>
          )}
        </div>

        <button
          onClick={onOpenAccount}
          className="p-1.5 hover:text-[#77736D] transition-colors"
          title="Account"
        >
          <User size={20} strokeWidth={1.5} />
        </button>

        <button
          onClick={onOpenWishlist}
          className="p-1.5 hover:text-[#77736D] transition-colors relative"
          title="Wishlist"
        >
          <Heart size={20} strokeWidth={1.5} />
          {wishlistCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#171717] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-medium">
              {wishlistCount}
            </span>
          )}
        </button>

        <button
          onClick={onOpenCart}
          className="p-1.5 hover:text-[#77736D] transition-colors relative"
          title="Shopping Bag"
        >
          <ShoppingBag size={20} strokeWidth={1.5} />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#171717] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-medium">
              {cartCount}
            </span>
          )}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="absolute top-[70px] left-0 w-full bg-[#F8F6F2] border-b border-[#E8E4DE] shadow-lg py-4 px-6 md:hidden flex flex-col gap-3 animate-fadeIn z-50">
          {navItems.map((item) => (
            <button
              key={item}
              onClick={() => {
                onSelectNav(item);
                setMobileMenuOpen(false);
              }}
              className={`text-left text-sm py-2 transition-colors ${
                activeNav === item ? 'font-semibold text-[#171717] pl-2 border-l-2 border-[#171717]' : 'text-[#77736D]'
              }`}
            >
              {item}
            </button>
          ))}
          <div className="pt-2 border-t border-[#E8E4DE] flex items-center justify-between text-xs text-[#77736D]">
            <button onClick={() => { onOpenAdmin(); setMobileMenuOpen(false); }} className="flex items-center gap-1 font-semibold text-[#171717]">
              <Shield size={14} /> Admin Center
            </button>
            <button onClick={() => { onOpenAccount(); setMobileMenuOpen(false); }} className="text-[#171717] font-medium underline">
              Account / DPDP Rights
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
