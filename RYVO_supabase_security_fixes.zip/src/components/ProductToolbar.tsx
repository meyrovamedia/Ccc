import React from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';

interface ProductToolbarProps {
  totalCount: number;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  sortBy: string;
  onSortChange: (sort: string) => void;
  onOpenMobileFilters: () => void;
}

export const ProductToolbar: React.FC<ProductToolbarProps> = ({
  totalCount,
  searchQuery,
  onSearchChange,
  sortBy,
  onSortChange,
  onOpenMobileFilters
}) => {
  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 mb-6 border-b border-[#E8E4DE] gap-4">
      <div>
        <h2 className="text-lg font-bold tracking-tight text-[#171717]">ALL PRODUCTS</h2>
        <p className="text-[11px] font-mono uppercase tracking-wider text-[#77736D] mt-0.5">
          THE NEXORA COLLECTION &bull; {totalCount} ITEMS
        </p>
      </div>

      <div className="flex items-center gap-3">
        {/* Mobile Filter Button */}
        <button
          onClick={onOpenMobileFilters}
          className="lg:hidden flex items-center gap-2 bg-[#F0EEEA] text-[#171717] px-3 py-2 rounded text-xs font-medium hover:bg-[#E8E4DE] transition-colors"
        >
          <SlidersHorizontal size={14} />
          <span>Filters</span>
        </button>

        {/* Search Input */}
        <div className="relative flex items-center">
          <Search size={14} className="absolute left-3 text-[#77736D]" />
          <input
            type="text"
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="bg-white border border-[#E8E4DE] rounded text-xs pl-9 pr-4 py-2 w-48 sm:w-60 focus:outline-none focus:border-[#171717] text-[#171717] placeholder-[#77736D]"
          />
        </div>

        {/* Sort Dropdown */}
        <div className="relative">
          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value)}
            className="bg-white border border-[#E8E4DE] rounded text-xs px-3 py-2 focus:outline-none focus:border-[#171717] text-[#171717] cursor-pointer"
          >
            <option value="featured">Sort by: Featured</option>
            <option value="newest">Sort by: Newest</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
          </select>
        </div>
      </div>
    </div>
  );
};
