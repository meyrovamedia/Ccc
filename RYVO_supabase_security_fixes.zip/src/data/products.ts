export interface Product {
  id: string;
  name: string;
  category: 'T-Shirts' | 'Shirts' | 'Overshirts' | 'Trousers' | 'Jeans' | 'Jackets';
  price: number;
  originalPrice?: number;
  image: string;
  images?: string[];
  video?: string;
  badge?: 'NEW' | 'BESTSELLER' | 'LIMITED';
  colors: string[]; // hex codes or color names
  sizes: string[];
  description: string;
  rating: number;
  reviewsCount: number;
}

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Oversized Utility Overshirt',
    category: 'Overshirts',
    price: 2790,
    image: '/src/assets/images/product_olive_overshirt_1793263932719.jpg',
    badge: 'NEW',
    colors: ['#556B2F', '#2F4F4F', '#A0522D', '#171717'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description: 'Crafted from heavy cotton twill with dual chest pockets and relaxed boxy drape. Designed for effortless layering across seasons.',
    rating: 4.8,
    reviewsCount: 42
  },
  {
    id: '2',
    name: 'Essential Oversized T-Shirt',
    category: 'T-Shirts',
    price: 1490,
    image: '/src/assets/images/product_white_tshirt_1793263932650.jpg',
    badge: 'BESTSELLER',
    colors: ['#FFFFFF', '#F5F5DC', '#808080', '#171717', '#556B2F'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description: 'Ultra-heavyweight combed cotton with a structured ribbed collar. Pre-shrunk for the ultimate boxy silhouette.',
    rating: 4.9,
    reviewsCount: 128
  },
  {
    id: '3',
    name: 'Premium Cotton Hoodie',
    category: 'T-Shirts', // or Jackets/Hoodies mapped to T-Shirts/New Arrivals
    price: 2490,
    image: '/src/assets/images/product_gray_hoodie_1793263932585.jpg',
    colors: ['#808080', '#171717', '#F5F5DC', '#A0522D'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Luxurious loopback fleece hoodie featuring double-layered hood and clean minimal pocketless front aesthetic.',
    rating: 4.7,
    reviewsCount: 89
  },
  {
    id: '4',
    name: 'Relaxed Fit Linen Shirt',
    category: 'Shirts',
    price: 2490,
    image: '/src/assets/images/product_linen_shirt_1793263951479.jpg',
    colors: ['#F5F5DC', '#FFFFFF', '#4682B4', '#171717'],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    description: 'Breathable French linen button-down with Cuban collar. Impeccably soft with natural textured drape.',
    rating: 4.6,
    reviewsCount: 54
  },
  {
    id: '5',
    name: 'Straight Fit Blue Jeans',
    category: 'Jeans',
    price: 2990,
    image: '/src/assets/images/product_blue_jeans_1793263951015.jpg',
    colors: ['#4682B4', '#171717', '#708090'],
    sizes: ['28', '30', '32', '34', '36', '38'],
    description: 'Rigid Japanese selvedge denim washed to an authentic mid-blue vintage finish. Built to soften and mold to you over time.',
    rating: 4.9,
    reviewsCount: 96
  },
  {
    id: '6',
    name: 'Casual Shirt',
    category: 'Shirts',
    price: 2290,
    image: '/src/assets/images/product_brown_shirt_1793263951705.jpg',
    colors: ['#A0522D', '#556B2F', '#171717', '#F5F5DC'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    description: 'Tencel-cotton blend shirt with horn buttons and a soft garment wash for lived-in comfort right from the first wear.',
    rating: 4.5,
    reviewsCount: 31
  },
  {
    id: '7',
    name: 'Structured Wool-Blend Jacket',
    category: 'Jackets',
    price: 4990,
    image: '/src/assets/images/hero_rail_clothing_1793263932773.jpg',
    badge: 'LIMITED',
    colors: ['#171717', '#808080', '#A0522D'],
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'Clean-lined minimalist jacket in a warming wool blend. Features concealed button placket and structured collar.',
    rating: 4.9,
    reviewsCount: 18
  },
  {
    id: '8',
    name: 'Pleated Tailored Trousers',
    category: 'Trousers',
    price: 2890,
    image: '/src/assets/images/hero_rail_clothing_1793263932773.jpg',
    colors: ['#F5F5DC', '#171717', '#808080'],
    sizes: ['28', '30', '32', '34', '36'],
    description: 'High-waisted pleated trousers with a relaxed tapered leg. Crisp pressed crease and adjustable side tabs.',
    rating: 4.7,
    reviewsCount: 65
  },
  {
    id: '9',
    name: 'Striped Resort Poplin Shirt',
    category: 'Shirts',
    price: 2390,
    image: '/src/assets/images/hero_rail_clothing_1793263932773.jpg',
    badge: 'NEW',
    colors: ['#4682B4', '#FFFFFF', '#171717'],
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'Crisp cotton poplin with classic navy and white stripes. Designed with a generous resort fit and mother-of-pearl buttons.',
    rating: 4.8,
    reviewsCount: 29
  },
  {
    id: '10',
    name: 'Heavyweight Pocket Tee',
    category: 'T-Shirts',
    price: 1590,
    image: '/src/assets/images/product_white_tshirt_1793263932650.jpg',
    colors: ['#171717', '#808080', '#556B2F', '#F5F5DC'],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    description: 'Classic crewneck tee featuring a single clean chest pocket and blind-stitch hems. The ultimate daily staple.',
    rating: 4.6,
    reviewsCount: 77
  },
  {
    id: '11',
    name: 'Relaxed Tapered Chinos',
    category: 'Trousers',
    price: 2690,
    image: '/src/assets/images/hero_rail_clothing_1793263932773.jpg',
    colors: ['#F5F5DC', '#A0522D', '#171717', '#556B2F'],
    sizes: ['28', '30', '32', '34', '36', '38'],
    description: 'Washed cotton twill trousers with comfortable stretch and a relaxed thigh that tapers neatly to the ankle.',
    rating: 4.7,
    reviewsCount: 84
  },
  {
    id: '12',
    name: 'Raw Indigo Denim Jacket',
    category: 'Jackets',
    price: 3890,
    image: '/src/assets/images/hero_rail_clothing_1793263932773.jpg',
    badge: 'BESTSELLER',
    colors: ['#4682B4', '#171717'],
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'Unwashed 14oz rigid denim jacket with antique brass hardware and adjustable waist tabs. Develops unique fades over time.',
    rating: 4.9,
    reviewsCount: 112
  }
];

export const CATEGORIES = [
  'All Clothing',
  'T-Shirts',
  'Overshirts',
  'Trousers',
  'Jeans',
  'Jackets',
  'New Arrivals'
];

export const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export const COLORS = [
  { name: 'White', hex: '#FFFFFF' },
  { name: 'Beige', hex: '#F5F5DC' },
  { name: 'Gray', hex: '#808080' },
  { name: 'Black', hex: '#171717' },
  { name: 'Olive', hex: '#556B2F' },
  { name: 'Brown', hex: '#A0522D' },
  { name: 'Blue', hex: '#4682B4' }
];
