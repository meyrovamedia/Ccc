-- Add a gateway-side order reference without changing existing order records.
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS gateway_order_id text;

CREATE UNIQUE INDEX IF NOT EXISTS orders_gateway_order_id_unique
  ON public.orders (gateway_order_id)
  WHERE gateway_order_id IS NOT NULL;
