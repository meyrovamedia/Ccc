-- Cancel a pending order and restore reserved stock exactly once.
CREATE OR REPLACE FUNCTION public.cancel_pending_order_and_restore_stock(p_order_id character varying)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
  v_order_id varchar;
BEGIN
  SELECT id
    INTO v_order_id
    FROM public.orders
   WHERE id = p_order_id
     AND status = 'Pending'
     AND payment_status = 'Pending'
   FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'reason', 'order_not_pending_or_already_processed');
  END IF;

  UPDATE public.orders
     SET status = 'Cancelled',
         payment_status = 'Failed'
   WHERE id = v_order_id;

  UPDATE public.products AS p
     SET stock = p.stock + q.quantity
    FROM (
      SELECT product_id, SUM(quantity)::integer AS quantity
        FROM public.order_items
       WHERE order_id = v_order_id
         AND product_id IS NOT NULL
       GROUP BY product_id
    ) AS q
   WHERE p.id = q.product_id;

  RETURN jsonb_build_object('success', true, 'order_id', v_order_id);
END;
$function$;

REVOKE EXECUTE ON FUNCTION public.cancel_pending_order_and_restore_stock(character varying)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_pending_order_and_restore_stock(character varying)
  TO service_role;
